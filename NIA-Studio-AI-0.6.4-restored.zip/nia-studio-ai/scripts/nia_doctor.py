#!/usr/bin/env python3
"""Read-only NIA preflight: reports configuration and model readiness without downloads."""
from __future__ import annotations
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys


def check_module(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def model_status(label: str, env_key: str, default: str) -> dict[str, object]:
    path = Path(os.getenv(env_key, default)).expanduser()
    present = path.is_dir() and (path / "model_index.json").is_file()
    return {"kind": label, "path": str(path), "directory_exists": path.is_dir(), "model_index_present": present,
            "status": "candidate_weights_present" if present else "weights_missing_or_unrecognized"}


def main() -> int:
    image_provider = os.getenv("NIA_IMAGE_PROVIDER", "local").strip().lower()
    video_provider = os.getenv("NIA_VIDEO_PROVIDER", "local").strip().lower()
    remote_allowed = False
    try:
        import torch  # type: ignore
        torch_info = {"installed": True, "version": torch.__version__, "cuda_available": bool(torch.cuda.is_available())}
    except Exception as exc:  # diagnostic must remain readable if torch is broken
        torch_info = {"installed": False, "error": type(exc).__name__, "cuda_available": False}
    report = {
        "application": "NIA Studio AI",
        "providers": {"image": image_provider, "video": video_provider, "remote_allowed": remote_allowed, "remote_policy": "hard-disabled"},
        "dependencies": {name: check_module(name) for name in ("fastapi", "diffusers", "transformers", "accelerate", "PIL")},
        "torch": torch_info,
        "tools": {"ffmpeg": shutil.which("ffmpeg"), "ffprobe": shutil.which("ffprobe"), "git": shutil.which("git")},
        "models": [model_status("image", "NIA_ENGINE_IMAGE_MODEL_DIR", "models/image"),
                   model_status("video", "NIA_ENGINE_VIDEO_MODEL_DIR", "models/video")],
        "verdict": "preflight_only_not_proof_of_generation",
        "next_step": "Install/pin licensed weights and run real offline image/video acceptance tests; this script downloads nothing.",
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
