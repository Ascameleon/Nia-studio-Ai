#!/usr/bin/env python3
"""Clone selected upstream repositories into isolated folders.

This script only retrieves source code. It does not install dependencies,
compile native projects, download model weights, or call generation APIs.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "upstream" / "manifest.json"


def load_manifest() -> dict:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if data.get("schema_version") != 1 or not isinstance(data.get("repositories"), list):
        raise ValueError("Unsupported or malformed upstream manifest")
    for repo in data["repositories"]:
        if not all(repo.get(key) for key in ("name", "url", "path", "role", "license")):
            raise ValueError("Each repository needs name, url, path, role and license")
        target = (ROOT / repo["path"]).resolve()
        if ROOT.resolve() not in target.parents:
            raise ValueError(f"Unsafe target path: {repo['path']}")
    return data


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", action="append", help="Repository name; may be repeated")
    parser.add_argument("--dry-run", action="store_true", help="Show planned commands only")
    parser.add_argument("--update", action="store_true", help="Fetch existing clones and fast-forward")
    args = parser.parse_args()
    try:
        repos = load_manifest()["repositories"]
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"Manifest error: {exc}", file=sys.stderr)
        return 2
    if args.only:
        known = {repo["name"] for repo in repos}
        unknown = set(args.only) - known
        if unknown:
            print("Unknown repository name(s): " + ", ".join(sorted(unknown)), file=sys.stderr)
            return 2
        repos = [repo for repo in repos if repo["name"] in args.only]
    if not shutil.which("git"):
        print("Git is required. Install Git and rerun this command.", file=sys.stderr)
        return 2

    failures = 0
    for repo in repos:
        target = ROOT / repo["path"]
        if (target / ".git").is_dir():
            command = ["git", "-C", str(target), "fetch", "--depth", "1", "origin"]
            if args.update:
                command = ["git", "-C", str(target), "pull", "--ff-only"]
            elif not args.dry_run:
                print(f"SKIP {repo['name']}: already cloned (use --update to fast-forward)")
                continue
        elif target.exists() and any(target.iterdir()):
            print(f"FAIL {repo['name']}: target exists and is not an empty Git clone: {target}", file=sys.stderr)
            failures += 1
            continue
        else:
            command = ["git", "clone", "--depth", "1", repo["url"], str(target)]
        print(f"[{repo['name']}] {repo['role']} | license review required: {repo['license']}")
        print("  " + " ".join(command))
        if args.dry_run:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        result = subprocess.run(command, cwd=ROOT, check=False)
        if result.returncode:
            print(f"FAIL {repo['name']}: git exited with {result.returncode}", file=sys.stderr)
            failures += 1
        else:
            print(f"OK {repo['name']}: source checkout present")
    if failures:
        print(f"Assembly finished with {failures} failure(s). No weights or dependencies were installed.", file=sys.stderr)
        return 1
    print("Source assembly command completed. This does NOT prove model inference works.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
