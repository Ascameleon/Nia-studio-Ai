from __future__ import annotations

import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


def db_path() -> str:
    return os.getenv("NIA_DATABASE", "./nia_studio.db")


def connect() -> sqlite3.Connection:
    path = Path(db_path())
    if str(path.parent) not in {"", "."}:
        path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def _db() -> Iterator[sqlite3.Connection]:
    """Connexion courte : commit si tout va bien, rollback sinon, fermeture dans tous les cas."""
    conn = connect()
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def init_db() -> None:
    with _db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            payload TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")


def save_project(payload: dict[str, Any], project_id: str | None = None) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    project_id = project_id or str(uuid.uuid4())
    brief = payload.get("brief")
    idea = brief.get("idea") if isinstance(brief, dict) else None
    title = str(payload.get("title") or idea or "Projet NIA")[:160]
    with _db() as conn:
        row = conn.execute("SELECT created_at FROM projects WHERE id=?", (project_id,)).fetchone()
        created = row["created_at"] if row else now
        conn.execute(
            """INSERT INTO projects(id,title,payload,created_at,updated_at) VALUES(?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET title=excluded.title,payload=excluded.payload,updated_at=excluded.updated_at""",
            (project_id, title, json.dumps(payload, ensure_ascii=False), created, now),
        )
    return {"id": project_id, "title": title, "payload": payload, "created_at": created, "updated_at": now}


def list_projects() -> list[dict[str, Any]]:
    with _db() as conn:
        rows = conn.execute("SELECT id,title,created_at,updated_at FROM projects ORDER BY updated_at DESC").fetchall()
    return [dict(r) for r in rows]


def get_project(project_id: str) -> dict[str, Any] | None:
    with _db() as conn:
        row = conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
    if not row:
        return None
    result = dict(row)
    result["payload"] = json.loads(result["payload"])
    return result


def delete_project(project_id: str) -> bool:
    with _db() as conn:
        cur = conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
    return cur.rowcount > 0
