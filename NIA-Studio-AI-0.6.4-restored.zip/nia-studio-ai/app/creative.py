from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, Field, field_validator


class Brief(BaseModel):
    idea: str = Field(min_length=3, max_length=5000)
    output_type: str = "short"
    duration_seconds: int = Field(default=10, ge=3, le=3600)
    aspect_ratio: str = "9:16"
    style: str = "Animation 3D cinéma"
    language: str = "Français"
    audience: str = "Grand public"
    goal: str = "Accroche forte et storytelling"
    scene_count: int = Field(default=4, ge=1, le=24)
    include_voiceover: bool = True
    include_captions: bool = True
    include_music: bool = True

    @field_validator("output_type")
    @classmethod
    def validate_output_type(cls, value: str) -> str:
        allowed = {"image", "short", "video", "storyboard"}
        if value not in allowed:
            raise ValueError(f"output_type must be one of {sorted(allowed)}")
        return value

    @field_validator("aspect_ratio")
    @classmethod
    def validate_ratio(cls, value: str) -> str:
        if value not in {"9:16", "16:9", "1:1", "4:5", "3:2"}:
            raise ValueError("Unsupported aspect ratio")
        return value


def _scene_title(index: int, count: int) -> str:
    if count == 1:
        return "Plan principal"
    names = ["Accroche visuelle", "Installation", "Progression", "Moment fort", "Résolution", "Final en boucle"]
    return names[index] if index < len(names) else f"Plan complémentaire {index + 1}"


def build_storyboard(brief: Brief) -> dict[str, Any]:
    """Turn a brief into a timed, editable production plan; no generation is faked."""
    count = 1 if brief.output_type == "image" else min(brief.scene_count, brief.duration_seconds)
    scenes: list[dict[str, Any]] = []
    for index in range(count):
        start = round(index * brief.duration_seconds / count, 2)
        end = round((index + 1) * brief.duration_seconds / count, 2)
        if brief.output_type == "image":
            start, end = 0.0, 0.0  # un plan fixe n'a pas de timing
        if index == 0:
            visual = (
                f"Ouvrir immédiatement sur une image forte liée à : {brief.idea}. "
                "Sujet clairement lisible, cadrage expressif, mouvement ou détail intrigant dès la première seconde."
            )
        elif index == count - 1:
            visual = (
                "Livrer le payoff visuel/émotionnel, garder le sujet reconnaissable et finir sur une composition "
                "mémorable. Pour un Short, prévoir un raccord possible avec le début."
            )
        else:
            visual = (
                f"Faire progresser l'idée sans répéter le plan précédent : {brief.idea}. "
                "Ajouter une action claire, une variation de cadrage et un détail visuel pertinent."
            )
        scenes.append({
            "index": index + 1,
            "title": _scene_title(index, count),
            "start_seconds": start,
            "end_seconds": end,
            "duration_seconds": round(end - start, 2),
            "visual_prompt": visual,
            "camera_direction": "Mouvement de caméra intentionnel, sujet net, profondeur cohérente, transition motivée par l'action.",
            "voiceover": "" if not brief.include_voiceover else f"Narration concise en {brief.language}, adaptée à : {brief.idea}.",
            "caption": "" if not brief.include_captions else "Sous-titre court, fort contraste, placé dans la zone de sécurité mobile.",
            "sound_design": "Musique et effets synchronisés, sans masquer la voix." if brief.include_music else "Aucune musique ajoutée.",
        })
    continuity = (
        "Conserver exactement l'identité du personnage, les couleurs, les vêtements, les proportions, les accessoires, "
        "la direction de lumière et le style de rendu entre les plans. Éviter les changements de visage, les membres "
        "supplémentaires, les textures qui scintillent, les mouvements impossibles et les textes illisibles."
    )
    prompt = (
        f"Créer {('une image fixe' if brief.output_type == 'image' else 'une vidéo')} à partir de cette idée : {brief.idea}\n"
        f"Style : {brief.style}. Public : {brief.audience}. Langue : {brief.language}. Objectif : {brief.goal}.\n"
        f"Format : {brief.aspect_ratio}. Durée cible : {brief.duration_seconds} secondes.\n\n"
        f"DIRECTION ARTISTIQUE\nHaute qualité visuelle, composition lisible, éclairage maîtrisé, profondeur, textures propres, "
        f"mouvements crédibles et rythme adapté au format. {continuity}\n\n"
        "STORYBOARD\n" + "\n\n".join(
            f"Plan {s['index']} ({s['start_seconds']}–{s['end_seconds']} s) — {s['title']}\n"
            f"Visuel : {s['visual_prompt']}\nCaméra : {s['camera_direction']}\n"
            f"Voix : {s['voiceover']}\nSous-titres : {s['caption']}\nSon : {s['sound_design']}"
            for s in scenes
        )
    )
    return {"brief": brief.model_dump(), "scenes": scenes, "continuity_rules": continuity, "production_prompt": prompt}


def safe_filename(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "-", value.strip()).strip("-").lower()
    return (value or "nia-project")[:64]
