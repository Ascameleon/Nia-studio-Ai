"""Adapter to the separately running, local-only NIA inference engine."""
from __future__ import annotations
import os
import asyncio
from typing import Any
from urllib.parse import urljoin
import httpx
from fastapi import HTTPException

BASE = os.getenv("NIA_LOCAL_ENGINE_URL", "http://127.0.0.1:8787").rstrip("/")
TIMEOUT = httpx.Timeout(connect=5.0, read=30.0, write=30.0, pool=5.0)

async def health() -> dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            r = await client.get(f"{BASE}/health")
            r.raise_for_status()
            return {"reachable": True, "base_url": BASE, "engine": r.json()}
    except (httpx.HTTPError, ValueError) as exc:
        return {"reachable": False, "base_url": BASE, "error": type(exc).__name__}

async def _request(method: str, path: str, **kwargs) -> dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            response = await client.request(method, f"{BASE}{path}", **kwargs)
            response.raise_for_status()
            return response.json()
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504, detail={"code":"local_engine_timeout", "message":"Le moteur local ne répond pas dans le délai prévu."}) from exc
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:1000]
        raise HTTPException(status_code=503, detail={"code":"local_engine_error", "message":detail}) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail={"code":"local_engine_unavailable", "message":f"Moteur local indisponible à {BASE}. Démarrez le noyau NIA local."}) from exc

async def create_image(prompt: str, size: str) -> dict[str, Any]:
    dimensions = {"1024x1024": (1024,1024), "1024x1536": (1024,1536), "1536x1024": (1536,1024)}
    if size not in dimensions:
        raise HTTPException(status_code=422, detail={"code":"unsupported_image_size", "message":"Format d'image non pris en charge."})
    width, height = dimensions[size]
    job = await _request("POST", "/v1/images", json={"prompt":prompt,"width":width,"height":height,"steps":25})
    job_id = job.get("job_id")
    if not job_id:
        raise HTTPException(status_code=502, detail={"code":"invalid_local_engine_response", "message":"Le moteur local n'a pas renvoyé d'identifiant de tâche."})
    # Image endpoint is synchronous from the studio's perspective; wait for a verified artifact.
    for _ in range(int(os.getenv("NIA_LOCAL_IMAGE_WAIT_SECONDS", "900")) // 2):
        await asyncio.sleep(2)
        state = await _request("GET", f"/v1/jobs/{job_id}")
        if state.get("status") == "succeeded":
            download = state.get("download_url")
            if not download:
                raise HTTPException(status_code=502, detail={"code":"missing_local_output", "message":"Le noyau a terminé sans lien de sortie."})
            return {"provider":"local", "model":"local-model", "job_id":job_id, "status":"succeeded", "images":[{"url":urljoin(BASE + "/", download.lstrip("/"))}], "output":urljoin(BASE + "/", download.lstrip("/"))}
        if state.get("status") in {"failed", "cancelled"}:
            raise HTTPException(status_code=502, detail={"code":"local_generation_failed", "message":state.get("error") or "La génération locale a échoué."})
    raise HTTPException(status_code=504, detail={"code":"local_image_timeout", "job_id":job_id, "message":"La génération dépasse le délai d'attente. Vérifiez la tâche dans le noyau local avant de la relancer."})

async def create_video(prompt: str, aspect_ratio: str, duration_seconds: int) -> dict[str, Any]:
    dimensions = {"9:16":(480,832), "16:9":(832,480), "1:1":(512,512)}
    if aspect_ratio not in dimensions:
        raise HTTPException(status_code=422, detail={"code":"unsupported_video_ratio", "message":"Format vidéo non pris en charge."})
    width, height = dimensions[aspect_ratio]
    fps = 16
    frames = max(17, min(257, duration_seconds * fps + 1))
    job = await _request("POST", "/v1/videos", json={"prompt":prompt,"frames":frames,"fps":fps,"height":height,"width":width,"steps":20})
    if not job.get("job_id"):
        raise HTTPException(status_code=502, detail={"code":"invalid_local_engine_response", "message":"Le moteur local n'a pas renvoyé d'identifiant de tâche."})
    return {"provider":"local", "job_id":job["job_id"], "status":job.get("status","queued"), "output":None, "urls":{"get":f"/api/jobs/local/{job['job_id']}"}}

async def get_video_job(job_id: str) -> dict[str, Any]:
    state = await _request("GET", f"/v1/jobs/{job_id}")
    output = state.get("download_url")
    output_url = urljoin(BASE + "/", output.lstrip("/")) if output else None
    return {"provider":"local", "job_id":job_id, "status":state.get("status"), "output":output_url, "error":state.get("error"), "urls":{"get":f"/api/jobs/local/{job_id}"}}
