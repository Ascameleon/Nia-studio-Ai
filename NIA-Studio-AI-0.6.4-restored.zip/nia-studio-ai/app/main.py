from __future__ import annotations

import hmac
import json
import logging
import os
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field
from starlette.middleware.sessions import SessionMiddleware
from starlette.requests import Request

from app.creative import Brief, build_storyboard
from app.providers import generate_image, generate_video, get_video_job, integration_status
from app.local_engine import health as local_engine_health
from app.store import delete_project, get_project, init_db, list_projects, save_project

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

logger = logging.getLogger("nia")
MAX_PROJECT_BYTES = 2_000_000
PUBLIC_PATHS = {"/api/health", "/api/auth/status", "/api/auth/login"}
LOGIN_WINDOW_SECONDS = 900
LOGIN_MAX_FAILURES = 5
_failed_logins: dict[str, list[float]] = {}


def _password_enabled() -> bool:
    return bool(os.getenv("NIA_STUDIO_PASSWORD"))


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(title="NIA Studio AI", version="0.6.4", description="Local-first AI creative studio with a shared generation core", lifespan=lifespan)


@app.middleware("http")
async def protect_private_api(request: Request, call_next):
    path = request.url.path
    if _password_enabled() and path.startswith("/api/") and path not in PUBLIC_PATHS and not request.session.get("nia_authenticated"):
        return JSONResponse(status_code=401, content={"detail": {"code": "authentication_required", "message": "Connectez-vous au studio NIA."}})
    return await call_next(request)


if _password_enabled() and not os.getenv("NIA_SESSION_SECRET"):
    # Refus de démarrer plutôt qu'une clé aléatoire : sans secret fixe, les sessions
    # tombent à chaque redémarrage et ne sont pas partagées entre workers.
    raise RuntimeError("NIA_STUDIO_PASSWORD est défini mais NIA_SESSION_SECRET est vide. Générez une valeur (voir .env.example).")

app.add_middleware(
    SessionMiddleware,
    secret_key=os.getenv("NIA_SESSION_SECRET") or secrets.token_urlsafe(48),  # jamais atteint si mot de passe défini
    same_site="lax",
    https_only=os.getenv("NIA_COOKIE_HTTPS_ONLY", "false").lower() == "true",
)


class SaveProjectRequest(BaseModel):
    id: str | None = None
    title: str | None = Field(default=None, max_length=160)
    payload: dict[str, Any]


class ImageRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=12000)
    size: str = Field(default="1024x1536", pattern=r"^(1024x1024|1024x1536|1536x1024)$")


class VideoRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=16000)
    aspect_ratio: str = Field(default="9:16", pattern=r"^(9:16|16:9|1:1)$")
    duration_seconds: int = Field(default=10, ge=3, le=3600)


class LoginRequest(BaseModel):
    password: str = Field(min_length=1, max_length=500)


@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    return (BASE_DIR / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/manifest.webmanifest")
async def manifest() -> FileResponse:
    return FileResponse(BASE_DIR / "static" / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/icon.svg")
async def icon() -> FileResponse:
    return FileResponse(BASE_DIR / "static" / "icon.svg", media_type="image/svg+xml")


@app.get("/sw.js")
async def service_worker() -> FileResponse:
    return FileResponse(BASE_DIR / "static" / "sw.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/api/health")
async def health(request: Request) -> dict[str, Any]:
    enabled = _password_enabled()
    return {
        "app": "NIA Studio AI",
        "version": app.version,
        "ready": True,
        "integrations": integration_status(),
        "auth_enabled": enabled,
        "authenticated": bool(request.session.get("nia_authenticated")) or not enabled,
    }


@app.get("/api/auth/status")
async def auth_status(request: Request) -> dict[str, bool]:
    enabled = _password_enabled()
    return {"enabled": enabled, "authenticated": bool(request.session.get("nia_authenticated")) or not enabled}


@app.post("/api/auth/login")
async def auth_login(request: Request, body: LoginRequest) -> dict[str, bool]:
    expected = os.getenv("NIA_STUDIO_PASSWORD")
    if not expected:
        return {"ok": True, "auth_required": False}
    key = request.client.host if request.client else "unknown"
    now = time.monotonic()
    recent = [t for t in _failed_logins.get(key, []) if now - t < LOGIN_WINDOW_SECONDS]
    _failed_logins[key] = recent
    if len(recent) >= LOGIN_MAX_FAILURES:
        raise HTTPException(status_code=429, detail={"code": "too_many_attempts", "message": "Trop de tentatives. Réessayez dans quinze minutes."})
    # encode en UTF-8 : compare_digest refuse les str non ASCII (accents, alphabet arabe...)
    if not hmac.compare_digest(body.password.encode("utf-8"), expected.encode("utf-8")):
        recent.append(now)
        raise HTTPException(status_code=401, detail={"code": "invalid_password", "message": "Mot de passe incorrect."})
    _failed_logins.pop(key, None)
    request.session["nia_authenticated"] = True
    return {"ok": True, "auth_required": True}


@app.post("/api/auth/logout")
async def auth_logout(request: Request) -> dict[str, bool]:
    request.session.clear()
    return {"ok": True}


@app.get("/api/engine/health")
async def engine_health() -> dict[str, Any]:
    """Actual engine reachability; separate from configuration status."""
    return await local_engine_health()


@app.get("/api/engine/comfyui/health")
async def comfyui_engine_health() -> dict[str, Any]:
    """ComfyUI reachability; separate from workflow/model configuration."""
    from app.comfyui_engine import health as comfyui_health
    return await comfyui_health()


@app.post("/api/storyboard")
async def storyboard(brief: Brief) -> dict[str, Any]:
    return build_storyboard(brief)


@app.get("/api/projects")
async def projects() -> list[dict[str, Any]]:
    return list_projects()


@app.post("/api/projects")
async def save(request: SaveProjectRequest) -> dict[str, Any]:
    if len(json.dumps(request.payload, ensure_ascii=False)) > MAX_PROJECT_BYTES:
        raise HTTPException(status_code=413, detail={"code": "project_too_large", "message": "Projet trop volumineux."})
    payload = dict(request.payload)
    if request.title:
        payload["title"] = request.title
    return save_project(payload, request.id)


@app.get("/api/projects/{project_id}")
async def project(project_id: str) -> dict[str, Any]:
    result = get_project(project_id)
    if not result:
        raise HTTPException(status_code=404, detail="Projet introuvable")
    return result


@app.delete("/api/projects/{project_id}")
async def remove_project(project_id: str) -> dict[str, bool]:
    if not delete_project(project_id):
        raise HTTPException(status_code=404, detail="Projet introuvable")
    return {"deleted": True}


@app.get("/api/projects/{project_id}/export.md", response_class=PlainTextResponse)
async def export_project(project_id: str) -> PlainTextResponse:
    item = get_project(project_id)
    if not item:
        raise HTTPException(status_code=404, detail="Projet introuvable")
    payload = item["payload"]
    brief = payload.get("brief", {})
    scenes = payload.get("scenes", [])
    lines = [f"# {item['title']}", "", "## Brief", f"- Idée : {brief.get('idea', '—')}", f"- Format : {brief.get('aspect_ratio', '—')}", f"- Durée : {brief.get('duration_seconds', '—')} s", "", "## Scènes"]
    for scene in scenes:
        lines += [f"### {scene.get('index', '')}. {scene.get('title', 'Scène')}", f"- Timing : {scene.get('start_seconds', 0)}–{scene.get('end_seconds', 0)} s", f"- Visuel : {scene.get('visual_prompt', '')}", f"- Caméra : {scene.get('camera_direction', '')}", f"- Voix : {scene.get('voiceover', '')}", f"- Sous-titre : {scene.get('caption', '')}", ""]
    lines += ["## Prompt de production", payload.get("production_prompt", "")]
    return PlainTextResponse("\n".join(lines), media_type="text/markdown", headers={"Content-Disposition": f'attachment; filename="nia-{project_id[:8]}.md"'})


@app.post("/api/generate/image")
async def image(request: ImageRequest) -> dict[str, Any]:
    return await generate_image(request.prompt, request.size)


@app.post("/api/generate/video")
async def video(request: VideoRequest) -> dict[str, Any]:
    return await generate_video(request.prompt, request.aspect_ratio, request.duration_seconds)


@app.get("/api/jobs/{provider}/{job_id}")
async def job(provider: str, job_id: str) -> dict[str, Any]:
    if provider == "replicate":
        raise HTTPException(status_code=403, detail={"code": "remote_provider_blocked", "message": "Le suivi des tâches distantes est désactivé dans NIA 0.6.4."})
    if provider != "local":
        raise HTTPException(status_code=400, detail="Fournisseur de suivi non pris en charge")
    return await get_video_job(job_id)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=int(os.getenv("PORT", "8000")), reload=False)
