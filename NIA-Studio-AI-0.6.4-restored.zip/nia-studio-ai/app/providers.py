from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from fastapi import HTTPException


def _remote_blocked(provider: str) -> HTTPException:
    return HTTPException(
        status_code=403,
        detail={
            "code": "remote_provider_blocked",
            "provider": provider,
            "message": "Cette version de NIA est strictement locale. Les fournisseurs distants sont désactivés et aucune variable d’environnement ne peut les réactiver.",
        },
    )


def integration_status() -> dict[str, Any]:
    image_provider = os.getenv("NIA_IMAGE_PROVIDER", "local").strip().lower()
    video_provider = os.getenv("NIA_VIDEO_PROVIDER", "local").strip().lower()
    local_url = os.getenv("NIA_LOCAL_ENGINE_URL", "http://127.0.0.1:8787").strip()
    local_configured = bool(local_url)

    custom_workflow = os.getenv("NIA_COMFYUI_WORKFLOW", "").strip()
    workflow_path = Path(custom_workflow).expanduser() if custom_workflow else (
        Path(__file__).resolve().parents[1] / "workflows" / "flux1_schnell_api.json"
    )
    workflow_available = workflow_path.is_file()

    image_supported = image_provider in {"local", "comfyui"}
    video_supported = video_provider == "local"
    image_configured = (image_provider == "local" and local_configured) or (
        image_provider == "comfyui" and workflow_available
    )
    video_configured = video_provider == "local" and local_configured

    return {
        "remote_policy": {"allow_remote": False, "default": "local-only", "enforced": True},
        "image": {
            "configured": image_configured,
            "provider": image_provider,
            "blocked": not image_supported,
            "workflow_available": workflow_available if image_provider == "comfyui" else None,
            "runtime_verified": False,
        },
        "video": {
            "configured": video_configured,
            "provider": video_provider,
            "blocked": not video_supported,
            "runtime_verified": False,
        },
        "audio": {"configured": False, "provider": None, "note": "Adaptateur audio non configuré."},
    }


async def generate_image(prompt: str, size: str = "1024x1536") -> dict[str, Any]:
    provider = os.getenv("NIA_IMAGE_PROVIDER", "local").strip().lower()
    if provider == "local":
        from app.local_engine import create_image
        return await create_image(prompt, size)
    if provider == "comfyui":
        from app.comfyui_engine import generate_image as comfy_generate_image
        return await comfy_generate_image(prompt, size)
    if provider == "replicate":
        raise _remote_blocked(provider)
    raise HTTPException(status_code=422, detail={"code": "unsupported_image_provider", "message": "Seuls les moteurs locaux NIA et ComfyUI sont pris en charge."})


async def generate_video(prompt: str, aspect_ratio: str = "9:16", duration_seconds: int = 10) -> dict[str, Any]:
    provider = os.getenv("NIA_VIDEO_PROVIDER", "local").strip().lower()
    if provider == "local":
        from app.local_engine import create_video
        return await create_video(prompt, aspect_ratio, duration_seconds)
    if provider == "replicate":
        raise _remote_blocked(provider)
    raise HTTPException(status_code=422, detail={"code": "unsupported_video_provider", "message": "La génération vidéo est limitée au moteur local NIA dans cette version."})


async def get_video_job(job_id: str) -> dict[str, Any]:
    provider = os.getenv("NIA_VIDEO_PROVIDER", "local").strip().lower()
    if provider == "local":
        from app.local_engine import get_video_job as get_local_video_job
        return await get_local_video_job(job_id)
    if provider == "replicate":
        raise _remote_blocked(provider)
    raise HTTPException(status_code=422, detail={"code": "unsupported_video_provider", "message": "Suivi de tâche limité au moteur local NIA."})
