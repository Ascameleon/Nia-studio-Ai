"""Adapter for a locally running ComfyUI server.

NIA never downloads model weights implicitly. A tested-shape FLUX.1 schnell API workflow is bundled; custom API workflows remain supported.
Placeholders {{prompt}}, {{width}}, {{height}}, and {{seed}} are replaced recursively.
"""
from __future__ import annotations
import asyncio, json, os, secrets
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
import httpx
from fastapi import HTTPException

DEFAULT_URL = "http://127.0.0.1:8188"
TIMEOUT = httpx.Timeout(connect=5, read=30, write=30, pool=5)

def _base() -> str:
    return os.getenv("NIA_COMFYUI_URL", DEFAULT_URL).rstrip("/")

def _workflow() -> dict[str, Any]:
    path = os.getenv("NIA_COMFYUI_WORKFLOW", "").strip()
    workflow_path = Path(path).expanduser() if path else Path(__file__).resolve().parents[1] / "workflows" / "flux1_schnell_api.json"
    try:
        obj = json.loads(workflow_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=503, detail={"code":"comfyui_workflow_invalid", "message":"Le fichier workflow ComfyUI est absent ou invalide."}) from exc
    if not isinstance(obj, dict) or not obj:
        raise HTTPException(status_code=503, detail={"code":"comfyui_workflow_invalid", "message":"Le workflow API doit être un objet JSON non vide."})
    return obj

def _replace(value: Any, prompt: str, width: int, height: int, seed: int) -> Any:
    if isinstance(value, dict): return {k: _replace(v,prompt,width,height,seed) for k,v in value.items()}
    if isinstance(value, list): return [_replace(v,prompt,width,height,seed) for v in value]
    if isinstance(value, str):
        typed = {"{{width}}": width, "{{height}}": height, "{{seed}}": seed}
        if value in typed: return typed[value]
        return value.replace("{{prompt}}",prompt).replace("{{width}}",str(width)).replace("{{height}}",str(height)).replace("{{seed}}",str(seed))
    return value

async def health() -> dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as c:
            r = await c.get(_base()+"/system_stats")
            r.raise_for_status()
            data = r.json()
        return {"reachable":True,"base_url":_base(),"engine":"ComfyUI","system":data}
    except (httpx.HTTPError, ValueError) as exc:
        return {"reachable":False,"base_url":_base(),"engine":"ComfyUI","error":type(exc).__name__}

async def generate_image(prompt: str, size: str) -> dict[str, Any]:
    sizes={"1024x1024":(1024,1024),"1024x1536":(1024,1536),"1536x1024":(1536,1024)}
    if size not in sizes:
        raise HTTPException(status_code=422,detail={"code":"unsupported_image_size","message":"Format d'image non pris en charge."})
    workflow=_replace(_workflow(),prompt,*sizes[size],secrets.randbelow(2**31-1))
    client_id=secrets.token_hex(16)
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as c:
            response=await c.post(_base()+"/prompt",json={"prompt":workflow,"client_id":client_id})
            response.raise_for_status(); payload=response.json()
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504,detail={"code":"comfyui_timeout","message":"ComfyUI a dépassé le délai de soumission."}) from exc
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502,detail={"code":"comfyui_rejected_workflow","message":exc.response.text[:1000]}) from exc
    except (httpx.HTTPError,ValueError) as exc:
        raise HTTPException(status_code=503,detail={"code":"comfyui_unavailable","message":f"ComfyUI local indisponible à {_base()}."}) from exc
    prompt_id=payload.get("prompt_id")
    if not isinstance(prompt_id,str) or not prompt_id:
        raise HTTPException(status_code=502,detail={"code":"comfyui_invalid_response","message":"ComfyUI n'a pas retourné prompt_id."})
    deadline=int(os.getenv("NIA_COMFYUI_IMAGE_WAIT_SECONDS","900"))
    for _ in range(max(1,deadline//2)):
        await asyncio.sleep(2)
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as c:
                r=await c.get(f"{_base()}/history/{prompt_id}"); r.raise_for_status(); history=r.json()
        except (httpx.HTTPError,ValueError) as exc:
            raise HTTPException(status_code=502,detail={"code":"comfyui_history_error","message":"Impossible de vérifier le résultat ComfyUI."}) from exc
        entry=history.get(prompt_id,{})
        outputs=entry.get("outputs",{}) if isinstance(entry,dict) else {}
        files=[]
        for node in outputs.values() if isinstance(outputs,dict) else []:
            if isinstance(node,dict):
                for item in node.get("images",[]):
                    if isinstance(item,dict) and isinstance(item.get("filename"),str): files.append(item)
        if files:
            urls=[]
            for f in files:
                query=urlencode({"filename":f["filename"],"subfolder":f.get("subfolder",""),"type":f.get("type","output")})
                urls.append({"url":f"{_base()}/view?{query}","filename":f["filename"]})
            return {"provider":"comfyui","model":"FLUX.1 schnell via ComfyUI (workflow configurable)","job_id":prompt_id,"status":"succeeded","images":urls,"output":urls[0]["url"]}
        status=entry.get("status",{}) if isinstance(entry,dict) else {}
        if isinstance(status,dict) and status.get("status_str")=="error":
            raise HTTPException(status_code=502,detail={"code":"comfyui_generation_failed","message":"ComfyUI a signalé une erreur pendant la génération."})
    raise HTTPException(status_code=504,detail={"code":"comfyui_image_timeout","job_id":prompt_id,"message":"La génération dépasse le délai prévu; vérifiez l'historique ComfyUI avant de relancer."})
