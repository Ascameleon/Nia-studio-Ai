@echo off
setlocal
cd /d "%~dp0"

if not exist .venv (
  python -m venv .venv || goto :error
)
call .venv\Scripts\activate.bat || goto :error
python -m pip install --upgrade pip || goto :error
pip install -r requirements.txt || goto :error

if not exist .env copy .env.example .env >nul
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
goto :eof

:error
echo.
echo Erreur pendant l'installation. Verifiez que Python 3.11+ est installe et dans le PATH.
pause
exit /b 1
