"""NIA Studio AI shared core: policy, contracts and registry."""
