"""Versioned contracts shared by NIA Studio and its local inference service."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any
import hashlib
import json
import uuid

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"

class MediaKind(str, Enum):
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"

@dataclass
class Artifact:
    path: str
    mime_type: str
    size_bytes: int
    sha256: str
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_path(cls, path: str | Path, mime_type: str, metadata: dict[str, Any] | None = None):
        p = Path(path)
        digest = hashlib.sha256()
        with p.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return cls(str(p), mime_type, p.stat().st_size, digest.hexdigest(), metadata or {})

@dataclass
class Job:
    project_id: str
    kind: MediaKind
    prompt: str
    model_id: str
    model_revision: str
    parameters: dict[str, Any] = field(default_factory=dict)
    job_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    status: JobStatus = JobStatus.QUEUED
    stage: str = "queued"
    progress: float | None = None
    attempt: int = 0
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)
    artifacts: list[Artifact] = field(default_factory=list)
    error_code: str | None = None
    error_message: str | None = None
    workflow_sha256: str | None = None
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["kind"] = self.kind.value
        result["status"] = self.status.value
        return result

    @classmethod
    def create(cls, *, project_id: str, kind: MediaKind | str, prompt: str,
               model_id: str, model_revision: str, parameters: dict[str, Any] | None = None):
        return cls(project_id=project_id, kind=MediaKind(kind), prompt=prompt,
                   model_id=model_id, model_revision=model_revision, parameters=parameters or {})

def workflow_hash(workflow: dict[str, Any]) -> str:
    raw = json.dumps(workflow, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()
