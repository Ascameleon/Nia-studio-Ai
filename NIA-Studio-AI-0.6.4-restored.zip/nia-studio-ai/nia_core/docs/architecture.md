# NIA Studio AI — architecture de consolidation

This overlay is additive: it retains the entire existing NIA Studio 0.5.0 / 0.5.1-kernel-assembly project and introduces a shared core under `nia_core/`. It does not claim to have merged the shared contracts into every existing route yet.

## Preserve and connect
- Keep `app/creative.py` as the creative brief/storyboard source of truth.
- Keep `app/main.py`, `app/providers.py`, `app/local_engine.py`, `app/store.py` and the existing static UI.
- Keep `nia-autonomous-engine/` as a separate local inference service.
- Use `nia_core/contracts.py` as the target cross-service contract for jobs/artifacts/provenance.
- Use `nia_core/policy.py` as the fail-closed gate before dispatching a generation.
- Use `nia_core/registry.py` to track exact model revision, license, local weights path and actual inference verification.
- Use `nia_core/job_state.py` for a durable job ledger; migrate existing persistence only after a compatibility test.

## Generation pipeline
Brief + constraints → storyboard and character/style bible → per-shot keyframes → local image/video adapter → optional local audio → FFmpeg assembly → artifact checks → visual/temporal review → export.

## Model adapter strategy
1. ComfyUI as an optional local graph runtime adapter (not vendored into this repository; review its GPL-3.0 obligations before distribution).
2. Diffusers adapter for supported models where direct pipeline integration is appropriate.
3. Specialized Wan/LTX adapters only after exact checkpoint, dependencies and license are pinned.
4. Remote provider code may remain for explicit opt-in experiments, but default/offline policy must reject remote dispatch.

## Status honesty
The new unit tests exercise the shared core only. They do not prove a real model loaded or generated an image/video. The upstream archive's previous audits also reported no model weights and no real inference test. Real generation acceptance remains a hard release gate.
