"""A tiny SQLite job ledger shared conceptually by studio and engine."""
from __future__ import annotations
import json, sqlite3
from pathlib import Path
from .contracts import Job, JobStatus, utc_now

_ALLOWED = {
    JobStatus.QUEUED: {JobStatus.RUNNING, JobStatus.CANCELLED, JobStatus.FAILED},
    JobStatus.RUNNING: {JobStatus.SUCCEEDED, JobStatus.FAILED, JobStatus.CANCELLED},
    JobStatus.SUCCEEDED: set(), JobStatus.FAILED: set(), JobStatus.CANCELLED: set(),
}

class JobLedger:
    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY, status TEXT NOT NULL, payload TEXT NOT NULL,
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")

    def create(self, job: Job) -> None:
        now = utc_now()
        job.created_at = job.updated_at = now
        with sqlite3.connect(self.path) as db:
            db.execute("INSERT INTO jobs VALUES (?, ?, ?, ?, ?)",
                       (job.job_id, job.status.value, json.dumps(job.to_dict()), now, now))

    def transition(self, job_id: str, status: JobStatus | str, *, stage: str | None = None,
                   error_code: str | None = None, error_message: str | None = None) -> dict:
        target = JobStatus(status)
        with sqlite3.connect(self.path) as db:
            row = db.execute("SELECT payload FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if not row:
                raise KeyError(job_id)
            payload = json.loads(row[0])
            current = JobStatus(payload["status"])
            if target not in _ALLOWED[current]:
                raise ValueError(f"Illegal job transition: {current.value} -> {target.value}")
            payload["status"] = target.value
            payload["stage"] = stage or target.value
            payload["updated_at"] = utc_now()
            payload["error_code"] = error_code
            payload["error_message"] = error_message
            db.execute("UPDATE jobs SET status=?, payload=?, updated_at=? WHERE job_id=?",
                       (target.value, json.dumps(payload), payload["updated_at"], job_id))
            return payload

    def get(self, job_id: str) -> dict | None:
        with sqlite3.connect(self.path) as db:
            row = db.execute("SELECT payload FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        return json.loads(row[0]) if row else None
