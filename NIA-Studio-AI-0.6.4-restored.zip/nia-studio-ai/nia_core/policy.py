"""Fail-closed policy gate: local-only by default, with auditable model readiness."""
from dataclasses import dataclass
from pathlib import Path
from typing import Any

class PolicyError(RuntimeError):
    pass

@dataclass(frozen=True)
class RuntimePolicy:
    allow_remote: bool = False
    require_license: bool = True
    require_weights: bool = True
    require_real_inference_verification: bool = True

def validate_generation_request(*, provider: str, model: dict[str, Any], weights_path: str | Path,
                                policy: RuntimePolicy = RuntimePolicy()) -> None:
    if provider != "local" and not policy.allow_remote:
        raise PolicyError(f"Remote provider '{provider}' is blocked by local-only policy.")
    if policy.require_license and not model.get("license"):
        raise PolicyError("Model has no recorded license; refusing to run.")
    if policy.require_weights and not Path(weights_path).exists():
        raise PolicyError("Model weights path does not exist.")
    if policy.require_real_inference_verification and model.get("inference_status") != "verified":
        raise PolicyError("Model has not passed a real inference acceptance test.")
