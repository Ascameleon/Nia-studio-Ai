import tempfile, unittest
from pathlib import Path
from nia_core.contracts import Job, JobStatus, MediaKind, workflow_hash
from nia_core.policy import RuntimePolicy, PolicyError, validate_generation_request
from nia_core.registry import ModelRegistry
from nia_core.job_state import JobLedger

class CoreTests(unittest.TestCase):
    def test_local_only_blocks_remote(self):
        with tempfile.TemporaryDirectory() as d:
            weights = Path(d) / "weights"; weights.mkdir()
            model = {"license":"Apache-2.0", "inference_status":"verified"}
            with self.assertRaises(PolicyError):
                validate_generation_request(provider="replicate", model=model, weights_path=weights)

    def test_policy_fails_closed_when_inference_unverified(self):
        with tempfile.TemporaryDirectory() as d:
            weights = Path(d) / "weights"; weights.mkdir()
            model = {"license":"Apache-2.0", "inference_status":"not_tested"}
            with self.assertRaises(PolicyError):
                validate_generation_request(provider="local", model=model, weights_path=weights)

    def test_registry_requires_evidence_fields(self):
        with tempfile.TemporaryDirectory() as d:
            reg = ModelRegistry(Path(d)/"models.json")
            with self.assertRaises(ValueError):
                reg.upsert({"model_id":"x"})

    def test_job_transition_contract(self):
        with tempfile.TemporaryDirectory() as d:
            ledger = JobLedger(Path(d)/"jobs.sqlite")
            job = Job.create(project_id="p", kind=MediaKind.IMAGE, prompt="test",
                             model_id="m", model_revision="rev")
            ledger.create(job)
            ledger.transition(job.job_id, JobStatus.RUNNING)
            ledger.transition(job.job_id, JobStatus.SUCCEEDED)
            with self.assertRaises(ValueError):
                ledger.transition(job.job_id, JobStatus.RUNNING)

    def test_workflow_hash_stable(self):
        self.assertEqual(workflow_hash({"b":2,"a":1}), workflow_hash({"a":1,"b":2}))

if __name__ == "__main__":
    unittest.main()
