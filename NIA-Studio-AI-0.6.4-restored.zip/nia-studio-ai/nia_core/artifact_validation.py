"""Basic output integrity checks; these do not certify visual quality."""
from pathlib import Path
import struct

class ArtifactValidationError(ValueError):
    pass

def validate_png(path: str | Path) -> dict:
    p = Path(path)
    if not p.is_file() or p.stat().st_size < 24:
        raise ArtifactValidationError("PNG missing or too small.")
    with p.open("rb") as f:
        header = f.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ArtifactValidationError("Invalid PNG signature/IHDR.")
    width, height = struct.unpack(">II", header[16:24])
    if width <= 0 or height <= 0:
        raise ArtifactValidationError("PNG dimensions must be positive.")
    return {"format": "PNG", "width": width, "height": height, "size_bytes": p.stat().st_size}

def validate_mp4_with_ffprobe(path: str | Path) -> dict:
    import json, shutil, subprocess
    p = Path(path)
    if not p.is_file() or p.stat().st_size == 0:
        raise ArtifactValidationError("MP4 missing or empty.")
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        raise ArtifactValidationError("ffprobe is required for MP4 validation.")
    proc = subprocess.run([ffprobe, "-v", "error", "-show_streams", "-show_format",
                           "-of", "json", str(p)], capture_output=True, text=True, timeout=30)
    if proc.returncode:
        raise ArtifactValidationError("ffprobe could not parse media.")
    data = json.loads(proc.stdout)
    videos = [s for s in data.get("streams", []) if s.get("codec_type") == "video"]
    if not videos:
        raise ArtifactValidationError("MP4 has no video stream.")
    duration = float(data.get("format", {}).get("duration", 0) or 0)
    if duration <= 0:
        raise ArtifactValidationError("MP4 duration must be positive.")
    stream = videos[0]
    if int(stream.get("width", 0)) <= 0 or int(stream.get("height", 0)) <= 0:
        raise ArtifactValidationError("MP4 dimensions must be positive.")
    return {"format": "MP4", "duration": duration, "width": int(stream["width"]),
            "height": int(stream["height"]), "has_audio": any(
                s.get("codec_type") == "audio" for s in data.get("streams", []))}
