"""Small local model registry; metadata is evidence, not a claim that a model works."""
from __future__ import annotations
from pathlib import Path
import json
from typing import Any

class ModelRegistry:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(json.dumps({"schema_version": 1, "models": []}, indent=2), encoding="utf-8")

    def list(self) -> list[dict[str, Any]]:
        return json.loads(self.path.read_text(encoding="utf-8"))["models"]

    def get(self, model_id: str) -> dict[str, Any] | None:
        return next((m for m in self.list() if m["model_id"] == model_id), None)

    def upsert(self, model: dict[str, Any]) -> None:
        required = {"model_id", "kind", "repo", "revision", "license", "weights_path", "inference_status"}
        missing = required - model.keys()
        if missing:
            raise ValueError(f"Missing registry fields: {', '.join(sorted(missing))}")
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        payload["models"] = [m for m in payload["models"] if m["model_id"] != model["model_id"]]
        payload["models"].append(model)
        self.path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
