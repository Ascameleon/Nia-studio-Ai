# NIA Studio AI 0.6.4 — hard local-only dispatch

## Correction
- Suppression du chemin HTTP Replicate dans le dispatch applicatif.
- Les fournisseurs distants sont bloqués même si `NIA_ALLOW_REMOTE_PROVIDERS=true` ou d’anciens tokens sont présents dans l’environnement.
- L’endpoint de suivi `/api/jobs/replicate/{job_id}` retourne 403.
- Le diagnostic en lecture seule rapporte toujours `remote_allowed=false` et `remote_policy=hard-disabled`.
- Version FastAPI corrigée à `0.6.4`; le README, les exemples et les notes de release sont alignés.

## Preuves attendues
- Tests API : tentatives image/vidéo Replicate avec token factice et opt-in ancien doivent retourner 403 sans créer de client HTTP distant.
- Tests de statut : `allow_remote=false` même avec l’ancienne variable à `true`.
- Tests locaux : ComfyUI et moteur NIA restent les seuls dispatchs autorisés.

## Limites non résolues
- Aucun poids FLUX/encodeur inclus; ComfyUI n’est pas embarqué.
- Le moteur NIA local reste un service séparé.
- Aucune génération image/vidéo réelle n’a été exécutée dans cette archive; CPU disponible, CUDA non détecté lors du préflight.
- Audio, montage multi-plans, narration, cohérence de personnage et export final restent à valider.
- Cette version n’est pas un produit de génération autonome prêt à publier.
