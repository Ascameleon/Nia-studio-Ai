# NIA Studio AI 0.6.0 — rapport de livraison

## Ce qui a été construit sur la base existante
- Conservation du studio, de son interface, des projets, du storyboard, de la couche de sécurité et du service d'inférence local existants.
- Conservation de `nia_core` (contrats communs, registre de modèles, politique locale, ledger de tâches, validation des artefacts) et du moteur local séparé.
- Nouvelle version applicative 0.6.0.
- Politique locale par défaut : les fournisseurs distants sont bloqués, sauf activation explicite par `NIA_ALLOW_REMOTE_PROVIDERS=true`.
- Nouveau point de contrôle `GET /api/engine/health` : mesure la joignabilité réelle du moteur local indépendamment du statut de configuration.
- Correction du suivi des tâches locales : `/api/jobs/local/{job_id}` est désormais accepté et routé vers le moteur local.
- Refus explicite des noms de fournisseurs vidéo inconnus au lieu de les traiter implicitement comme Replicate.
- Tests supplémentaires sur la politique locale, l'état du moteur et le suivi des tâches.

## Vérifications exécutées
- Tests du studio existant et de la nouvelle version : **27 réussis**.
- Compilation Python (`compileall`) : réussie.
- Le résultat des tests est une validation du code et des contrats, pas une preuve de génération par un modèle réel.

## Limites connues — ne pas confondre avec une livraison de génération réelle
- Aucun poids de modèle n'est inclus dans cette archive.
- Aucun rendu réel d'image ou de vidéo n'a été exécuté lors de cette vérification.
- Il faut installer/configurer les modèles locaux compatibles, puis exécuter des tests d'acceptation réels sur la machine cible.
- La narration audio, la musique et le montage multi-plans exportable ne sont pas encore validés de bout en bout.
- Les fournisseurs distants restent optionnels et désactivés par défaut ; leur activation peut entraîner des coûts et des transferts de données externes.

## Démarrage
1. Installer les dépendances du studio à partir de `requirements.txt`.
2. Copier `.env.example` vers `.env` et conserver `NIA_IMAGE_PROVIDER=local`, `NIA_VIDEO_PROVIDER=local`, `NIA_ALLOW_REMOTE_PROVIDERS=false`.
3. Installer les dépendances du moteur dans `nia-autonomous-engine/requirements-engine.txt`.
4. Configurer les chemins des poids avec `NIA_ENGINE_IMAGE_MODEL_DIR` et `NIA_ENGINE_VIDEO_MODEL_DIR`.
5. Démarrer le moteur local sur le port 8787, puis le studio.
6. Vérifier `/api/health` et `/api/engine/health`, puis réaliser un rendu réel et inspecter les fichiers de sortie.
