# Audit croisé — preuves, manques et décisions

Les archives 0.5.1 et moteur 0.1.2 ont été utilisées comme base, non remplacées.
- Studio: `app/main.py`, `providers.py`, `local_engine.py`, `store.py`, `creative.py`, UI statique, tests, script d'assemblage upstream.
- Moteur: `nia_engine/models.py`, `service.py`, `api.py`, `config.py`, tests, scripts de diagnostic/téléchargement.

## Bloquants issus des audits antérieurs
1. Pas de poids de modèles dans les archives inspectées.
2. Pas de preuve d'inférence réelle image/vidéo; les tests précédents reposent sur des fixtures/fakes.
3. Le défaut de dispatch distant identifié en 0.6.3 est corrigé en 0.6.4 : le dispatch applicatif n’expose plus de chemin Replicate; les variables d’environnement ne peuvent pas réactiver un fournisseur distant.
4. Le studio et le moteur n'ont pas encore été migrés vers un contrat commun de tâches.
5. Le storyboard existe, mais la production complète multi-plans, narration/audio local et export QA ne sont pas prouvés.
6. Les upstreams externes n'ont pas été clonés dans l'environnement précédent; l'assemblage reste à exécuter, à pinner et à auditer.

## Nouveaux éléments ajoutés
- `nia_core/contracts.py`: modèle de tâche, états, artefacts avec SHA-256, empreinte du workflow.
- `nia_core/policy.py`: politique local-only et refus fail-closed tant que licence, poids et inférence réelle ne sont pas prouvés.
- `nia_core/registry.py`: registre JSON avec champs de preuve.
- `nia_core/job_state.py`: journal SQLite et transitions d'état contrôlées.
- `nia_core/artifact_validation.py`: validation initiale PNG et MP4 via ffprobe.
- `nia_core/tests/test_core.py`: tests unitaires du noyau.
- `config/model_registry_candidates.json`: modèles candidats, explicitement marqués non testés.
- `nia_core/docs/architecture.md`: plan d'intégration additive.

## Non prétendu
Aucune génération réelle n'a été exécutée. Les nouveaux modules sont une couche de consolidation ajoutée à l'archive existante; les routes actuelles ne sont pas encore toutes migrées vers ces contrats. Aucun poids ni dépendance lourde n'a été téléchargé.
