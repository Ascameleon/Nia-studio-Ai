import json
from pathlib import Path
import pytest
from fastapi import HTTPException
from app import comfyui_engine



def test_workflow_placeholders_replaced_recursively():
    workflow = {"1": {"inputs": {"text": "{{prompt}}", "width": "{{width}}", "seed": "{{seed}}"}}}
    result = comfyui_engine._replace(workflow, "a cat", 512, 768, 123)
    assert result["1"]["inputs"] == {"text": "a cat", "width": 512, "seed": 123}


def test_workflow_rejects_invalid_json_file(monkeypatch, tmp_path):
    p = tmp_path / "bad.json"
    p.write_text("not json", encoding="utf-8")
    monkeypatch.setenv("NIA_COMFYUI_WORKFLOW", str(p))
    with pytest.raises(HTTPException) as exc:
        comfyui_engine._workflow()
    assert exc.value.detail["code"] == "comfyui_workflow_invalid"


def test_comfyui_provider_status(monkeypatch, tmp_path):
    from app.providers import integration_status
    workflow = tmp_path / "workflow.json"
    workflow.write_text('{"1": {"inputs": {"text": "{{prompt}}"}}}', encoding="utf-8")
    monkeypatch.setenv("NIA_IMAGE_PROVIDER", "comfyui")
    monkeypatch.setenv("NIA_COMFYUI_WORKFLOW", str(workflow))
    status = integration_status()
    assert status["image"]["provider"] == "comfyui"
    assert status["image"]["configured"] is True


def test_bundled_flux_workflow_available_without_env(monkeypatch):
    monkeypatch.delenv("NIA_COMFYUI_WORKFLOW", raising=False)
    workflow = comfyui_engine._workflow()
    assert workflow["1"]["class_type"] == "UNETLoader"
    assert workflow["2"]["class_type"] == "DualCLIPLoader"
    assert workflow["9"]["class_type"] == "SaveImage"
