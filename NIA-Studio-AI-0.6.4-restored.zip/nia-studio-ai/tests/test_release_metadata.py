from pathlib import Path
import tomllib


def test_package_version_matches_release_documentation():
    root = Path(__file__).resolve().parents[1]
    metadata = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    assert metadata["project"]["version"] == "0.6.4"
    assert "0.6.4" in (root / "README.md").read_text(encoding="utf-8")
