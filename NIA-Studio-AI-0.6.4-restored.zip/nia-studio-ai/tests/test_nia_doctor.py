import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_doctor_is_read_only_and_emits_json(tmp_path):
    env = dict(os.environ)
    env["NIA_ENGINE_IMAGE_MODEL_DIR"] = str(tmp_path / "no-image-model")
    env["NIA_ENGINE_VIDEO_MODEL_DIR"] = str(tmp_path / "no-video-model")
    result = subprocess.run([sys.executable, str(ROOT / "scripts" / "nia_doctor.py")], cwd=ROOT,
                            env=env, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0
    report = json.loads(result.stdout)
    assert report["verdict"] == "preflight_only_not_proof_of_generation"
    assert report["providers"]["remote_allowed"] is False
    assert all(not item["model_index_present"] for item in report["models"])
    assert not (tmp_path / "no-image-model").exists()
