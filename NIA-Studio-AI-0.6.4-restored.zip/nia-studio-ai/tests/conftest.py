import os

import pytest


@pytest.fixture(autouse=True)
def isolated_env(tmp_path, monkeypatch):
    """Chaque test part d'un environnement propre : pas de NIA_* issu d'un .env local, base SQLite temporaire."""
    for key in [k for k in os.environ if k.startswith("NIA_")]:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("NIA_DATABASE", str(tmp_path / "nia_test.db"))


@pytest.fixture(autouse=True)
def reset_login_limiter():
    """Le compteur de tentatives est global au processus : on le remet à zéro entre les tests."""
    from app import main
    main._failed_logins.clear()
    yield
    main._failed_logins.clear()
