from app.creative import Brief, build_storyboard


def test_storyboard_scene_timing_covers_duration():
    brief = Brief(idea="Un chaton apprend les couleurs", duration_seconds=10, scene_count=4)
    result = build_storyboard(brief)
    assert len(result["scenes"]) == 4
    assert result["scenes"][0]["start_seconds"] == 0
    assert result["scenes"][-1]["end_seconds"] == 10
    assert all(s["end_seconds"] >= s["start_seconds"] for s in result["scenes"])


def test_image_is_one_scene():
    result = build_storyboard(Brief(idea="Portrait de dragon", output_type="image", duration_seconds=10))
    assert len(result["scenes"]) == 1
    assert "image fixe" in result["production_prompt"]


def test_continuity_and_prompt_are_present():
    result = build_storyboard(Brief(idea="Ville futuriste au lever du soleil", scene_count=3))
    assert "identité du personnage" in result["continuity_rules"]
    assert "STORYBOARD" in result["production_prompt"]
    assert result["scenes"][0]["voiceover"]


def test_optional_audio_flags():
    result = build_storyboard(Brief(idea="Un paysage marin", include_voiceover=False, include_music=False))
    assert all(s["voiceover"] == "" for s in result["scenes"])
    assert all(s["sound_design"] == "Aucune musique ajoutée." for s in result["scenes"])
