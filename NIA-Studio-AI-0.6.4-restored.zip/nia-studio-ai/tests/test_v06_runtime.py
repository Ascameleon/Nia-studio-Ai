from fastapi.testclient import TestClient
from fastapi import HTTPException

from app.main import app
from app import providers


def test_runtime_reports_local_first_remote_policy(monkeypatch):
    monkeypatch.setenv("NIA_IMAGE_PROVIDER", "local")
    monkeypatch.setenv("NIA_VIDEO_PROVIDER", "local")
    monkeypatch.setenv("NIA_ALLOW_REMOTE_PROVIDERS", "true")
    status = providers.integration_status()
    assert status["remote_policy"]["default"] == "local-only"
    assert status["remote_policy"]["allow_remote"] is False
    assert status["remote_policy"]["enforced"] is True


def test_remote_image_generation_is_blocked_by_default(monkeypatch):
    monkeypatch.setenv("NIA_IMAGE_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_REPLICATE_API_TOKEN", "test-token")
    monkeypatch.setenv("NIA_REPLICATE_IMAGE_VERSION", "test-version")
    monkeypatch.setenv("NIA_ALLOW_REMOTE_PROVIDERS", "true")
    import asyncio
    try:
        asyncio.run(providers.generate_image("A mountain landscape", "1024x1024"))
    except HTTPException as exc:
        assert exc.status_code == 403
        assert exc.detail["code"] == "remote_provider_blocked"
    else:
        raise AssertionError("Remote generation should be blocked by default")


def test_local_engine_health_endpoint_is_separate_from_studio_health():
    with TestClient(app) as client:
        response = client.get("/api/engine/health")
        assert response.status_code == 200
        payload = response.json()
        assert "reachable" in payload
        assert "base_url" in payload


def test_local_job_route_is_accepted(monkeypatch):
    async def fake_local_job(job_id):
        return {"provider": "local", "job_id": job_id, "status": "queued", "output": None, "error": None, "urls": {}}
    monkeypatch.setattr("app.local_engine.get_video_job", fake_local_job)
    monkeypatch.setenv("NIA_VIDEO_PROVIDER", "local")
    with TestClient(app) as client:
        response = client.get("/api/jobs/local/abc123")
        assert response.status_code == 200
        assert response.json()["provider"] == "local"


def test_remote_video_generation_is_hard_blocked_even_if_legacy_opt_in_is_true(monkeypatch):
    monkeypatch.setenv("NIA_VIDEO_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_ALLOW_REMOTE_PROVIDERS", "true")
    monkeypatch.setenv("NIA_REPLICATE_API_TOKEN", "dummy-never-sent")
    monkeypatch.setenv("NIA_REPLICATE_VIDEO_VERSION", "dummy-version")
    import asyncio
    try:
        asyncio.run(providers.generate_video("A cinematic ocean scene", "16:9", 10))
    except HTTPException as exc:
        assert exc.status_code == 403
        assert exc.detail["code"] == "remote_provider_blocked"
    else:
        raise AssertionError("Remote video generation must remain blocked")


def test_remote_configuration_is_never_reported_as_configured(monkeypatch):
    monkeypatch.setenv("NIA_IMAGE_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_VIDEO_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_ALLOW_REMOTE_PROVIDERS", "true")
    monkeypatch.setenv("NIA_REPLICATE_API_TOKEN", "dummy-never-sent")
    monkeypatch.setenv("NIA_REPLICATE_IMAGE_VERSION", "dummy-version")
    status=providers.integration_status()
    assert status["remote_policy"]["allow_remote"] is False
    assert status["image"]["configured"] is False and status["image"]["blocked"] is True
    assert status["video"]["configured"] is False and status["video"]["blocked"] is True
