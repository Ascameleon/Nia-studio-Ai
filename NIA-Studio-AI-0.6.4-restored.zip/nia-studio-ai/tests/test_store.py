import os
from app import store


def test_project_crud(tmp_path, monkeypatch):
    monkeypatch.setenv("NIA_DATABASE", str(tmp_path / "test.db"))
    store.init_db()
    saved = store.save_project({"title": "Essai", "brief": {"idea": "Test"}})
    assert store.get_project(saved["id"])["payload"]["title"] == "Essai"
    assert any(p["id"] == saved["id"] for p in store.list_projects())
    assert store.delete_project(saved["id"])
    assert store.get_project(saved["id"]) is None


def test_update_preserves_created_at(tmp_path, monkeypatch):
    monkeypatch.setenv("NIA_DATABASE", str(tmp_path / "update.db"))
    store.init_db()
    first = store.save_project({"title": "Initial", "brief": {"idea": "First"}}, "stable-id")
    second = store.save_project({"title": "Updated", "brief": {"idea": "Second"}}, "stable-id")
    assert first["created_at"] == second["created_at"]
    assert store.get_project("stable-id")["title"] == "Updated"
