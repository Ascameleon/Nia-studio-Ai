import asyncio

from app import local_engine


def _capture(monkeypatch):
    sent = {}

    async def fake(method, path, **kwargs):
        sent.update(kwargs.get("json", {}))
        return {"job_id": "job-1", "status": "queued"}

    monkeypatch.setattr(local_engine, "_request", fake)
    return sent


def test_vertical_video_is_portrait(monkeypatch):
    sent = _capture(monkeypatch)
    asyncio.run(local_engine.create_video("océan", "9:16", 5))
    assert sent["height"] > sent["width"]


def test_landscape_video_is_landscape(monkeypatch):
    sent = _capture(monkeypatch)
    asyncio.run(local_engine.create_video("océan", "16:9", 5))
    assert sent["width"] > sent["height"]


def test_video_dimensions_are_multiples_of_16(monkeypatch):
    sent = _capture(monkeypatch)
    for ratio in ("9:16", "16:9", "1:1"):
        asyncio.run(local_engine.create_video("test", ratio, 5))
        assert sent["width"] % 16 == 0 and sent["height"] % 16 == 0
