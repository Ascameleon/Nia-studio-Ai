from fastapi.testclient import TestClient

from app import store
from app.main import app


def test_project_without_brief_is_saved(tmp_path, monkeypatch):
    monkeypatch.setenv("NIA_DATABASE", str(tmp_path / "hardening.db"))
    store.init_db()
    saved = store.save_project({"title": "Sans brief", "brief": None})
    assert saved["title"] == "Sans brief"


def test_oversized_project_is_refused():
    with TestClient(app) as client:
        response = client.post("/api/projects", json={"payload": {"blob": "x" * 2_100_000}})
        assert response.status_code == 413


def test_password_with_accents_does_not_crash(monkeypatch):
    monkeypatch.setenv("NIA_STUDIO_PASSWORD", "clé-secrète-é")
    with TestClient(app) as client:
        assert client.post("/api/auth/login", json={"password": "clé-secrète-é"}).status_code == 200
        assert client.post("/api/auth/login", json={"password": "clé-secrete-e"}).status_code == 401


def test_login_is_rate_limited(monkeypatch):
    monkeypatch.setenv("NIA_STUDIO_PASSWORD", "bon-mot-de-passe")
    with TestClient(app) as client:
        for _ in range(5):
            assert client.post("/api/auth/login", json={"password": "mauvais"}).status_code == 401
        assert client.post("/api/auth/login", json={"password": "mauvais"}).status_code == 429
        # même le bon mot de passe est bloqué pendant la fenêtre
        assert client.post("/api/auth/login", json={"password": "bon-mot-de-passe"}).status_code == 429


def test_image_storyboard_has_no_timing():
    from app.creative import Brief, build_storyboard
    result = build_storyboard(Brief(idea="Portrait de dragon", output_type="image"))
    assert result["scenes"][0]["start_seconds"] == 0
    assert result["scenes"][0]["end_seconds"] == 0
