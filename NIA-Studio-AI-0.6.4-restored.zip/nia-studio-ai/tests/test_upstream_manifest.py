import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_manifest_has_required_kernels_and_https_urls():
    manifest = json.loads((ROOT / "upstream/manifest.json").read_text(encoding="utf-8"))
    names = {repo["name"] for repo in manifest["repositories"]}
    assert {"pytorch", "diffusers", "transformers", "accelerate", "ComfyUI", "FFmpeg"} <= names
    assert all(repo["url"].startswith("https://github.com/") for repo in manifest["repositories"])


def test_assembly_script_supports_dry_run():
    spec = importlib.util.spec_from_file_location("assemble_upstreams", ROOT / "scripts/assemble_upstreams.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    data = module.load_manifest()
    assert len(data["repositories"]) >= 6
