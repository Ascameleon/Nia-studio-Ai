from fastapi.testclient import TestClient
from app.main import app


def test_health_and_frontend():
    with TestClient(app) as client:
        assert client.get("/api/health").status_code == 200
        page = client.get("/")
        assert page.status_code == 200
        assert "NIA Studio AI" in page.text
        assert client.get("/api/projects").status_code == 200


def test_storyboard_validation():
    with TestClient(app) as client:
        response = client.post("/api/storyboard", json={"idea": "Dragon sur une montagne", "duration_seconds": 12, "scene_count": 3})
        assert response.status_code == 200
        data = response.json()
        assert len(data["scenes"]) == 3
        assert data["scenes"][-1]["end_seconds"] == 12


def test_image_generation_refuses_to_fake_result(monkeypatch):
    monkeypatch.setenv("NIA_IMAGE_PROVIDER", "replicate")
    monkeypatch.delenv("NIA_REPLICATE_API_TOKEN", raising=False)
    monkeypatch.delenv("NIA_REPLICATE_IMAGE_VERSION", raising=False)
    with TestClient(app) as client:
        response = client.post("/api/generate/image", json={"prompt": "Portrait d'un dragon bleu détaillé"})
        assert response.status_code == 403
        assert response.json()["detail"]["code"] == "remote_provider_blocked"


def test_optional_password_protection(monkeypatch):
    monkeypatch.setenv("NIA_STUDIO_PASSWORD", "test-secret")
    with TestClient(app) as client:
        blocked = client.get("/api/projects")
        assert blocked.status_code == 401
        bad = client.post("/api/auth/login", json={"password": "wrong"})
        assert bad.status_code == 401
        good = client.post("/api/auth/login", json={"password": "test-secret"})
        assert good.status_code == 200
        assert client.get("/api/projects").status_code == 200
        assert client.post("/api/auth/logout").status_code == 200
        assert client.get("/api/projects").status_code == 401


def test_image_size_validation_happens_before_provider_call(monkeypatch):
    monkeypatch.setenv("NIA_IMAGE_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_VIDEO_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_REPLICATE_API_TOKEN", "test-key")
    monkeypatch.setenv("NIA_REPLICATE_IMAGE_VERSION", "test-version")
    with TestClient(app) as client:
        response = client.post("/api/generate/image", json={"prompt": "A cinematic mountain landscape", "size": "1x1"})
        assert response.status_code == 422


def test_video_input_validation_rejects_unknown_aspect_ratio():
    with TestClient(app) as client:
        response = client.post("/api/generate/video", json={"prompt": "A cinematic ocean scene", "aspect_ratio": "4:3", "duration_seconds": 10})
        assert response.status_code == 422


def test_video_generation_never_fakes_missing_provider(monkeypatch):
    monkeypatch.setenv("NIA_IMAGE_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_VIDEO_PROVIDER", "replicate")
    monkeypatch.delenv("NIA_REPLICATE_API_TOKEN", raising=False)
    monkeypatch.delenv("NIA_REPLICATE_VIDEO_VERSION", raising=False)
    with TestClient(app) as client:
        response = client.post("/api/generate/video", json={"prompt": "A cinematic ocean scene"})
        assert response.status_code == 403
        assert response.json()["detail"]["code"] == "remote_provider_blocked"


def test_remote_job_route_is_hard_blocked_even_if_legacy_opt_in_is_true(monkeypatch):
    monkeypatch.setenv("NIA_VIDEO_PROVIDER", "replicate")
    monkeypatch.setenv("NIA_ALLOW_REMOTE_PROVIDERS", "true")
    monkeypatch.setenv("NIA_REPLICATE_API_TOKEN", "dummy-never-sent")
    with TestClient(app) as client:
        response = client.get("/api/jobs/replicate/abc123")
        assert response.status_code == 403
        assert response.json()["detail"]["code"] == "remote_provider_blocked"
