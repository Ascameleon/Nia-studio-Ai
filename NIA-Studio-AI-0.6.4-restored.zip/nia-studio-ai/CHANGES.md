# Changelog — check complet (0.4.0)

## Corrigé (bugs confirmés)
- `app/main.py` : le mot de passe comportant un caractère non ASCII (accents, alphabet arabe) provoquait une `TypeError` au lieu d'un refus propre. Comparaison désormais en UTF-8.
- `app/store.py` : chaque opération SQLite ouvrait une connexion jamais fermée. Connexions désormais fermées systématiquement.
- `app/store.py` : `save_project` plantait si `brief` valait `null`.
- `static/index.html` : passer sur « Image IA » mettait le nombre de scènes à `1`, valeur absente de la liste ; l'API renvoyait une 422 et l'utilisateur voyait du JSON brut. Le listener fautif est supprimé.
- `static/index.html` : les erreurs de validation (422) s'affichent en texte lisible.
- `static/index.html` : après connexion, le storyboard est reconstruit (il échouait au chargement de la page, car la session n'existait pas encore).
- `static/sw.js` : la stratégie cache-first gardait l'ancienne interface après une mise à jour. Passage en réseau d'abord, cache en secours hors ligne, cache versionné `v2`.
- `static/manifest.webmanifest` : une seule icône déclarée « any maskable » ; séparée en « any » et « maskable ».

## Renforcé
- `app/main.py` : taille maximale d'un projet sauvegardé (2 Mo, sinon 413).
- `app/main.py` : avertissement au démarrage si le mot de passe est défini sans `NIA_SESSION_SECRET`.
- `app/main.py` : imports inutilisés retirés, `hmac` importé en tête de fichier.
- `app/providers.py` : une réponse 2xx non JSON du fournisseur renvoie une 502 claire au lieu d'une 500.

## Tests
- `tests/conftest.py` : chaque test isole son environnement (pas de `NIA_*` issu d'un `.env` local) et utilise une base SQLite temporaire. Avant, les tests écrivaient `nia_studio.db` dans le projet.
- `tests/test_hardening.py` : couvre les quatre points ci-dessus (projet sans brief, taille maximale, mot de passe accentué).

## Traité dans cette passe
- Force brute : 5 échecs de connexion par 15 minutes et par adresse, puis 429 (y compris pour le bon mot de passe pendant la fenêtre).
- Sessions : sans `NIA_SESSION_SECRET`, l'application refuse de démarrer si un mot de passe est défini. Les sessions survivent aux redémarrages et fonctionnent avec plusieurs workers.
- Image : le storyboard n'affiche plus de timing pour un plan fixe.

## Hors périmètre du code
- Montage multi-plans, narration, musique et export vidéo final : fonctionnalités à développer, pas des réglages.
- Les tests n'ont pas pu être exécutés dans l'environnement de préparation (pas de réseau, FastAPI absent). `pytest -q` reste à lancer.
