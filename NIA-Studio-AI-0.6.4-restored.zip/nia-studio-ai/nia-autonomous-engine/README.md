# NIA local engine 0.1.2

Service de génération local. Il écoute sur 127.0.0.1:8787 et n'appelle aucune API distante.

## Lancer
```bash
pip install -r requirements-engine.txt -r ../requirements-kernels.txt   # torch à choisir selon la machine
export NIA_ENGINE_IMAGE_MODEL_DIR=models/image   # dossier local, téléchargé explicitement
export NIA_ENGINE_VIDEO_MODEL_DIR=models/video
uvicorn nia_engine.api:create_app --factory --host 127.0.0.1 --port 8787
```

## Routes
- `GET /health` : état, périphérique, présence des modèles.
- `POST /v1/images` : `{prompt, width, height, steps}` → `job_id` (202).
- `POST /v1/videos` : `{prompt, frames, fps, width, height, steps}` → `job_id` (202).
- `GET /v1/jobs/{id}` : statut, erreur, `download_url` quand la sortie est vérifiée.
- `GET /v1/outputs/{id}` : fichier PNG ou MP4 vérifié.

## Garanties
- Une tâche n'est `succeeded` qu'après vérification du fichier (signature PNG, flux vidéo lisible).
- Modèles chargés avec `local_files_only=True` : aucun téléchargement implicite.
- Après redémarrage, les tâches interrompues passent en `failed`.
- Une génération à la fois (un seul worker).

## Limites connues
- Le chargement des modèles et la génération réelle n'ont pas été testés : aucun poids n'est installé dans ce livrable.
- Pas d'authentification : ne jamais exposer ce port hors de la machine.
