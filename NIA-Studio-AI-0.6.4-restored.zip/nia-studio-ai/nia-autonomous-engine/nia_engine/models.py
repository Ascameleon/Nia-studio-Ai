"""Local diffusion model adapters. Models are loaded from disk only (local_files_only=True).

No code in this module contacts a remote generation API, and no weights are downloaded here.
"""
from __future__ import annotations

from pathlib import Path


class EngineError(Exception):
    """Controlled engine error with a readable message. Never triggers a remote fallback."""


VALID_DEVICES = ("auto", "cpu", "cuda")


def choose_device(preference: str = "auto") -> str:
    pref = (preference or "auto").strip().lower()
    if pref not in VALID_DEVICES:
        raise EngineError(f"Unknown device {preference!r}. Expected one of: auto, cpu, cuda.")
    if pref == "cpu":
        return "cpu"
    try:
        import torch
    except ImportError as exc:
        if pref == "cuda":
            raise EngineError("PyTorch is not installed; CUDA cannot be used.") from exc
        return "cpu"
    if torch.cuda.is_available():
        return "cuda"
    if pref == "cuda":
        raise EngineError("CUDA was requested but no NVIDIA GPU is available.")
    return "cpu"


def _require_model_dir(path: Path, label: str) -> None:
    if not path.is_dir():
        raise EngineError(
            f"{label} model directory does not exist: {path}. "
            "Download it explicitly with scripts/download_models.py."
        )


class LocalImageModel:
    def __init__(self, model_dir: Path, device: str) -> None:
        self.model_dir = Path(model_dir)
        self.device = device
        self._pipe = None

    def load(self):
        if self._pipe is None:
            _require_model_dir(self.model_dir, "Image")
            import torch
            from diffusers import DiffusionPipeline

            dtype = torch.float16 if self.device == "cuda" else torch.float32
            pipe = DiffusionPipeline.from_pretrained(
                str(self.model_dir), local_files_only=True, torch_dtype=dtype
            )
            self._pipe = pipe.to(self.device)
        return self._pipe

    def generate(self, prompt: str, output_path: Path, width: int = 1024, height: int = 1024,
                 steps: int = 25, **_: object) -> Path:
        pipe = self.load()
        image = pipe(prompt=prompt, width=width, height=height, num_inference_steps=steps).images[0]
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        image.save(output_path, format="PNG")
        return output_path


class LocalVideoModel:
    def __init__(self, model_dir: Path, device: str) -> None:
        self.model_dir = Path(model_dir)
        self.device = device
        self._pipe = None

    def load(self):
        if self._pipe is None:
            _require_model_dir(self.model_dir, "Video")
            import torch
            from diffusers import DiffusionPipeline

            dtype = torch.float16 if self.device == "cuda" else torch.float32
            pipe = DiffusionPipeline.from_pretrained(
                str(self.model_dir), local_files_only=True, torch_dtype=dtype
            )
            self._pipe = pipe.to(self.device)
        return self._pipe

    def generate(self, prompt: str, output_path: Path, frames: int = 17, fps: int = 16,
                 width: int = 832, height: int = 480, steps: int = 20, **_: object) -> Path:
        pipe = self.load()
        from diffusers.utils import export_to_video

        result = pipe(prompt=prompt, height=height, width=width,
                      num_frames=frames, num_inference_steps=steps)
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        export_to_video(result.frames[0], str(output_path), fps=fps)
        return output_path
