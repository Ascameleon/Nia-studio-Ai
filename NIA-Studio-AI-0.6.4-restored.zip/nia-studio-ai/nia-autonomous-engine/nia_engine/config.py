from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _env_path(name: str, default: str) -> Path:
    return Path(os.getenv(name, default))


@dataclass
class Settings:
    data_dir: Path = field(default_factory=lambda: _env_path("NIA_ENGINE_DATA_DIR", "./engine-data"))
    image_model_dir: Path = field(default_factory=lambda: _env_path("NIA_ENGINE_IMAGE_MODEL_DIR", "models/image"))
    video_model_dir: Path = field(default_factory=lambda: _env_path("NIA_ENGINE_VIDEO_MODEL_DIR", "models/video"))
    device: str = field(default_factory=lambda: os.getenv("NIA_ENGINE_DEVICE", "auto"))

    def __post_init__(self) -> None:
        self.data_dir = Path(self.data_dir)
        self.image_model_dir = Path(self.image_model_dir)
        self.video_model_dir = Path(self.video_model_dir)

    @property
    def jobs_dir(self) -> Path:
        return self.data_dir / "jobs"

    @property
    def outputs_dir(self) -> Path:
        return self.data_dir / "outputs"

    def prepare(self) -> None:
        self.jobs_dir.mkdir(parents=True, exist_ok=True)
        self.outputs_dir.mkdir(parents=True, exist_ok=True)
