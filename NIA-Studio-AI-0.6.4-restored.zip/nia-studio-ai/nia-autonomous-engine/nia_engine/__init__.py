"""NIA local inference engine: local-only image and video generation service."""
__version__ = "0.1.2"
