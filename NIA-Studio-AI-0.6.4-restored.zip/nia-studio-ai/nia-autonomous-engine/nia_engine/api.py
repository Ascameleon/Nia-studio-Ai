"""HTTP API used by NIA Studio (app/local_engine.py). Binds to localhost; no authentication, local use only."""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .config import Settings
from .models import EngineError, LocalImageModel, LocalVideoModel, choose_device
from .service import EngineService


class ImageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)
    width: int = 1024
    height: int = 1024
    steps: int = 25


class VideoRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)
    frames: int = 17
    fps: int = 16
    width: int = 832
    height: int = 480
    steps: int = 20


def _error(status: int, exc: EngineError) -> HTTPException:
    return HTTPException(status_code=status, detail={"code": "engine_error", "message": str(exc)})


def create_app(settings: Settings | None = None, service: EngineService | None = None) -> FastAPI:
    if service is None:
        settings = settings or Settings()
        # Échec explicite au démarrage si le périphérique demandé est indisponible.
        device = choose_device(settings.device)
        service = EngineService(
            settings,
            LocalImageModel(settings.image_model_dir, device),
            LocalVideoModel(settings.video_model_dir, device),
        )

    app = FastAPI(title="NIA Local Engine", version="0.1.2")
    app.state.service = service

    @app.on_event("shutdown")
    def _shutdown() -> None:
        service.close()

    @app.get("/health")
    def health() -> dict[str, Any]:
        return service.health()

    @app.post("/v1/images", status_code=202)
    def create_image(request: ImageRequest) -> dict[str, Any]:
        try:
            job_id = service.create_job("image", request.prompt,
                                        {"width": request.width, "height": request.height, "steps": request.steps})
        except EngineError as exc:
            raise _error(422, exc) from exc
        return {"job_id": job_id, "status": "queued"}

    @app.post("/v1/videos", status_code=202)
    def create_video(request: VideoRequest) -> dict[str, Any]:
        try:
            job_id = service.create_job("video", request.prompt, {
                "frames": request.frames, "fps": request.fps, "width": request.width,
                "height": request.height, "steps": request.steps,
            })
        except EngineError as exc:
            raise _error(422, exc) from exc
        return {"job_id": job_id, "status": "queued"}

    @app.get("/v1/jobs/{job_id}")
    def job(job_id: str) -> dict[str, Any]:
        record = service.get_job(job_id)
        if record is None:
            raise HTTPException(status_code=404, detail={"code": "job_not_found", "message": "Tâche introuvable."})
        download = f"/v1/outputs/{job_id}" if record["status"] == "succeeded" else None
        return {
            "id": record["id"], "kind": record["kind"], "status": record["status"],
            "error": record["error"], "download_url": download,
            "created_at": record["created_at"], "updated_at": record["updated_at"],
        }

    @app.get("/v1/outputs/{job_id}")
    def output(job_id: str) -> FileResponse:
        try:
            path = service.get_output(job_id)
        except EngineError as exc:
            raise _error(409, exc) from exc
        media = "image/png" if path.suffix == ".png" else "video/mp4"
        return FileResponse(path, media_type=media)

    return app
