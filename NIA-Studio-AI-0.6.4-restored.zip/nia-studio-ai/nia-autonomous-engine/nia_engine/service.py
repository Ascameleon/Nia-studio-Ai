"""Job service: validates requests, runs one generation at a time, verifies outputs, persists history."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import Settings
from .models import EngineError

logger = logging.getLogger("nia_engine")

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
MAX_PROMPT_CHARS = 4000
ACTIVE_STATUSES = {"queued", "running"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _int(params: dict[str, Any], key: str, default: int) -> int:
    try:
        return int(params.get(key, default))
    except (TypeError, ValueError) as exc:
        raise EngineError(f"Parameter '{key}' must be an integer.") from exc


class EngineService:
    def __init__(self, settings: Settings, image_model: Any, video_model: Any) -> None:
        self.settings = settings
        self.settings.prepare()
        self.image_model = image_model
        self.video_model = video_model
        self._lock = threading.Lock()
        self._jobs: dict[str, dict[str, Any]] = {}
        # Un seul worker : un GPU ne traite qu'une génération à la fois.
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="nia-engine")
        self._load_history()

    # ----- history -------------------------------------------------------
    def _load_history(self) -> None:
        for path in self.settings.jobs_dir.glob("*.json"):
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                logger.warning("Ignoring unreadable job file %s", path)
                continue
            if record.get("status") in ACTIVE_STATUSES:
                record["status"] = "failed"
                record["error"] = "Interrupted: service restarted before completion."
                record["updated_at"] = _now()
                self._write(record)
            self._jobs[record["id"]] = record

    def _write(self, record: dict[str, Any]) -> None:
        path = self.settings.jobs_dir / f"{record['id']}.json"
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    def _update(self, job_id: str, **changes: Any) -> None:
        with self._lock:
            record = self._jobs[job_id]
            record.update(changes, updated_at=_now())
            self._write(record)

    # ----- validation ----------------------------------------------------
    def _validate(self, kind: str, params: dict[str, Any]) -> dict[str, Any]:
        if kind == "image":
            width = _int(params, "width", 1024)
            height = _int(params, "height", 1024)
            steps = _int(params, "steps", 25)
            if not (64 <= width <= 2048 and 64 <= height <= 2048):
                raise EngineError("Image dimensions must be between 64 and 2048 pixels.")
            if width % 8 or height % 8:
                raise EngineError("Image dimensions must be multiples of 8.")
            if not 1 <= steps <= 100:
                raise EngineError("Image steps must be between 1 and 100.")
            return {"width": width, "height": height, "steps": steps}

        frames = _int(params, "frames", 17)
        fps = _int(params, "fps", 16)
        width = _int(params, "width", 832)
        height = _int(params, "height", 480)
        steps = _int(params, "steps", 20)
        if width % 16 or height % 16:
            raise EngineError("Video dimensions must be multiples of 16.")
        if not (64 <= width <= 1280 and 64 <= height <= 1280):
            raise EngineError("Video dimensions must be between 64 and 1280 pixels.")
        if not 9 <= frames <= 257:
            raise EngineError("Video frames must be between 9 and 257.")
        if (frames - 1) % 4:
            raise EngineError("Video frames must follow the 4n+1 rule (for example 17, 33, 65).")
        if not 1 <= fps <= 30:
            raise EngineError("Video fps must be between 1 and 30.")
        if not 1 <= steps <= 100:
            raise EngineError("Video steps must be between 1 and 100.")
        return {"frames": frames, "fps": fps, "width": width, "height": height, "steps": steps}

    # ----- public API ----------------------------------------------------
    def create_job(self, kind: str, prompt: str, params: dict[str, Any] | None = None) -> str:
        if kind not in ("image", "video"):
            raise EngineError(f"Unsupported generation kind: {kind!r}.")
        prompt = (prompt or "").strip()
        if not prompt:
            raise EngineError("Prompt is empty.")
        if len(prompt) > MAX_PROMPT_CHARS:
            raise EngineError(f"Prompt is too long (maximum {MAX_PROMPT_CHARS} characters).")
        clean = self._validate(kind, dict(params or {}))

        job_id = uuid.uuid4().hex
        record = {
            "id": job_id, "kind": kind, "prompt": prompt, "params": clean,
            "status": "queued", "output": None, "error": None,
            "created_at": _now(), "updated_at": _now(),
        }
        with self._lock:
            self._jobs[job_id] = record
            self._write(record)
        self._executor.submit(self._run, job_id)
        return job_id

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        with self._lock:
            record = self._jobs.get(job_id)
            return dict(record) if record else None

    def get_output(self, job_id: str) -> Path:
        record = self.get_job(job_id)
        if not record or record["status"] != "succeeded" or not record.get("output"):
            raise EngineError("Output is not available: the job has not completed successfully.")
        path = Path(record["output"])
        if not path.is_file():
            raise EngineError("Output file is missing from the engine data directory.")
        return path

    def health(self) -> dict[str, Any]:
        return {
            "mode": "local-only",
            "external_generation_apis": False,
            "device": self.settings.device,
            "image_model_installed": _model_present(self.settings.image_model_dir),
            "video_model_installed": _model_present(self.settings.video_model_dir),
        }

    def close(self) -> None:
        self._executor.shutdown(wait=False, cancel_futures=True)

    # ----- execution -----------------------------------------------------
    def _run(self, job_id: str) -> None:
        record = self.get_job(job_id)
        if record is None:
            return
        kind = record["kind"]
        ext = "png" if kind == "image" else "mp4"
        output = self.settings.outputs_dir / f"{job_id}.{ext}"
        self._update(job_id, status="running")
        try:
            model = self.image_model if kind == "image" else self.video_model
            model.generate(record["prompt"], output, **record["params"])
            _validate_output(kind, output)
        except EngineError as exc:
            output.unlink(missing_ok=True)
            self._update(job_id, status="failed", error=str(exc))
            return
        except Exception as exc:  # noqa: BLE001 - toute erreur de modèle devient un échec explicite
            logger.exception("Generation %s failed", job_id)
            output.unlink(missing_ok=True)
            self._update(job_id, status="failed", error=f"{type(exc).__name__}: {exc}")
            return
        self._update(job_id, status="succeeded", output=str(output))


def _model_present(path: Path) -> bool:
    return path.is_dir() and (path / "model_index.json").is_file()


def _validate_output(kind: str, path: Path) -> None:
    if not path.is_file() or path.stat().st_size == 0:
        raise EngineError("Output validation failed: file is missing or empty.")
    if kind == "image":
        with path.open("rb") as handle:
            if handle.read(8) != PNG_SIGNATURE:
                raise EngineError("Output validation failed: file is not a valid PNG.")
        return
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        proc = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)],
            capture_output=True, text=True, timeout=60,
        )
        if proc.returncode != 0 or "video" not in proc.stdout:
            raise EngineError("Output validation failed: no readable video stream.")
        return
    with path.open("rb") as handle:
        if handle.read(12)[4:8] != b"ftyp":
            raise EngineError("Output validation failed: file is not an MP4 container.")
