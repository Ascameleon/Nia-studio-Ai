from pathlib import Path

import pytest
import shutil
import subprocess

from nia_engine.config import Settings
from nia_engine.models import EngineError
from nia_engine.service import EngineService


class FakeModel:
    def __init__(self, fail=False):
        self.fail = fail

    def generate(self, prompt, output_path, **kwargs):
        if self.fail:
            raise EngineError("model unavailable in test")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if output_path.suffix == ".png":
            from PIL import Image
            Image.new("RGB", (32, 32), (220, 30, 40)).save(output_path, format="PNG")
        else:
            ffmpeg = shutil.which("ffmpeg")
            if not ffmpeg:
                raise EngineError("ffmpeg missing for video test fixture")
            subprocess.run([ffmpeg, "-v", "error", "-f", "lavfi", "-i",
                            "color=c=blue:s=32x32:d=1", "-pix_fmt", "yuv420p",
                            "-y", str(output_path)], check=True, capture_output=True)
        return output_path


def make_service(tmp_path, image=None, video=None):
    settings = Settings(data_dir=tmp_path / "data", image_model_dir=tmp_path / "models" / "image",
                        video_model_dir=tmp_path / "models" / "video", device="cpu")
    return EngineService(settings, image_model=image or FakeModel(), video_model=video or FakeModel())


def wait_job(service, job_id):
    import time
    for _ in range(100):
        record = service.get_job(job_id)
        if record["status"] in {"succeeded", "failed"}:
            return record
        time.sleep(0.01)
    raise AssertionError("job timed out")


def test_health_explicitly_local_only(tmp_path):
    health = make_service(tmp_path).health()
    assert health["mode"] == "local-only"
    assert health["external_generation_apis"] is False
    assert health["image_model_installed"] is False
    assert health["video_model_installed"] is False


def test_image_job_requires_real_output_file(tmp_path):
    service = make_service(tmp_path)
    job_id = service.create_job("image", "a red apple", {"width": 512, "height": 512, "steps": 2})
    job = wait_job(service, job_id)
    assert job["status"] == "succeeded"
    from PIL import Image
    with Image.open(job["output"]) as image:
        assert image.format == "PNG"
        assert image.size == (32, 32)
    assert service.get_output(job_id).is_file()


def test_video_job_requires_real_output_file(tmp_path):
    service = make_service(tmp_path)
    job_id = service.create_job("video", "a moving ocean", {"frames": 9, "steps": 2, "fps": 8})
    job = wait_job(service, job_id)
    assert job["status"] == "succeeded"
    assert Path(job["output"]).suffix == ".mp4"
    assert Path(job["output"]).stat().st_size > 0
    assert shutil.which("ffprobe")


def test_failed_model_is_not_reported_as_success(tmp_path):
    service = make_service(tmp_path, image=FakeModel(fail=True))
    job_id = service.create_job("image", "test", {"width": 512, "height": 512, "steps": 2})
    job = wait_job(service, job_id)
    assert job["status"] == "failed"
    assert "model unavailable" in job["error"]
    with pytest.raises(EngineError):
        service.get_output(job_id)


def test_rejects_empty_prompt(tmp_path):
    service = make_service(tmp_path)
    with pytest.raises(EngineError):
        service.create_job("image", "  ", {})


def test_rejects_unsupported_generation_kind(tmp_path):
    service = make_service(tmp_path)
    with pytest.raises(EngineError):
        service.create_job("audio", "hello", {})


def test_rejects_oversized_image(tmp_path):
    service = make_service(tmp_path)
    with pytest.raises(EngineError):
        service.create_job("image", "test", {"width": 9000, "height": 512, "steps": 2})


def test_rejects_excessive_video_frames(tmp_path):
    service = make_service(tmp_path)
    with pytest.raises(EngineError):
        service.create_job("video", "test", {"frames": 999, "steps": 2, "fps": 8})


def test_output_cannot_be_downloaded_before_completion(tmp_path):
    service = make_service(tmp_path, image=FakeModel(fail=True))
    job_id = service.create_job("image", "test", {"width": 512, "height": 512, "steps": 2})
    wait_job(service, job_id)
    with pytest.raises(EngineError):
        service.get_output(job_id)


def test_missing_local_image_model_fails_without_remote_fallback(tmp_path):
    from nia_engine.models import LocalImageModel
    model = LocalImageModel(tmp_path / "missing-image-model", "cpu")
    with pytest.raises(EngineError, match="does not exist"):
        model.generate("a landscape", tmp_path / "out.png")
    assert not (tmp_path / "out.png").exists()


def test_missing_local_video_model_fails_without_remote_fallback(tmp_path):
    from nia_engine.models import LocalVideoModel
    model = LocalVideoModel(tmp_path / "missing-video-model", "cpu")
    with pytest.raises(EngineError, match="does not exist"):
        model.generate("a moving landscape", tmp_path / "out.mp4")
    assert not (tmp_path / "out.mp4").exists()


def test_job_history_restored_after_service_restart(tmp_path):
    settings = Settings(data_dir=tmp_path / "data", image_model_dir=tmp_path / "models" / "image",
                        video_model_dir=tmp_path / "models" / "video", device="cpu")
    first = EngineService(settings, image_model=FakeModel(), video_model=FakeModel())
    job_id = first.create_job("image", "a red apple", {"width": 512, "height": 512, "steps": 2})
    completed = wait_job(first, job_id)
    assert completed["status"] == "succeeded"

    restored = EngineService(settings, image_model=FakeModel(), video_model=FakeModel())
    record = restored.get_job(job_id)
    assert record is not None
    assert record["status"] == "succeeded"
    assert restored.get_output(job_id).is_file()


def test_interrupted_job_is_marked_failed_after_restart(tmp_path):
    settings = Settings(data_dir=tmp_path / "data", image_model_dir=tmp_path / "models" / "image",
                        video_model_dir=tmp_path / "models" / "video", device="cpu")
    settings.prepare()
    job_id = "interrupted123"
    (settings.jobs_dir / f"{job_id}.json").write_text(
        '{"id":"interrupted123","kind":"image","prompt":"test","params":{},"status":"running","output":null,"error":null}',
        encoding="utf-8")
    restored = EngineService(settings, image_model=FakeModel(), video_model=FakeModel())
    record = restored.get_job(job_id)
    assert record["status"] == "failed"
    assert "restarted" in record["error"]


def test_model_load_is_explicitly_local_only():
    import inspect
    from nia_engine.models import LocalImageModel, LocalVideoModel
    image_source = inspect.getsource(LocalImageModel.load)
    video_source = inspect.getsource(LocalVideoModel.load)
    assert "local_files_only=True" in image_source
    assert "local_files_only=True" in video_source
    assert "from_pretrained" in image_source and "from_pretrained" in video_source


def test_non_image_bytes_are_not_accepted_as_success(tmp_path):
    class InvalidImageModel:
        def generate(self, prompt, output_path, **kwargs):
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(b"this is not a png")
            return output_path

    service = make_service(tmp_path, image=InvalidImageModel())
    job_id = service.create_job("image", "test", {"width": 512, "height": 512, "steps": 2})
    job = wait_job(service, job_id)
    assert job["status"] == "failed"
    assert "validation" in job["error"].lower()


def test_video_dimensions_must_be_multiple_of_16(tmp_path):
    service = make_service(tmp_path)
    with pytest.raises(EngineError, match="multiples of 16"):
        service.create_job("video", "moving ocean", {"frames": 9, "steps": 2, "fps": 8,
                                                       "width": 830, "height": 480})
