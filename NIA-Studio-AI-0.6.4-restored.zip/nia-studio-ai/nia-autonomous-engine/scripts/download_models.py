#!/usr/bin/env python3
"""Explicit, one-time model downloader. Never called by the inference engine.

Downloading models consumes bandwidth and disk space. Run only after reviewing
model terms and confirming available storage; no download happens by default.
"""
from __future__ import annotations

import argparse
from pathlib import Path

MODELS = {
    "image": {
        "repo": "PixArt-alpha/PixArt-Sigma-XL-2-1024-MS",
        "license": "CreativeML Open RAIL++-M",
        "dest": Path("models/image"),
        "note": "Open weights with use restrictions; review model card and license before use.",
    },
    "video": {
        "repo": "Wan-AI/Wan2.1-T2V-1.3B-Diffusers",
        "license": "Apache-2.0",
        "dest": Path("models/video"),
        "note": "Large model download; check available disk space and hardware first.",
    },
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=["image", "video", "all"], help="Choose which model to download explicitly")
    parser.add_argument("--allow-large-download", action="store_true",
                        help="Required for video/all because video weights are large")
    parser.add_argument("--root", type=Path, default=Path("."), help="Engine project root")
    args = parser.parse_args()
    chosen = list(MODELS) if args.kind == "all" else [args.kind]
    if "video" in chosen and not args.allow_large_download:
        parser.error("Video weights are large; re-run with --allow-large-download after checking storage and bandwidth")
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        parser.error("huggingface_hub is missing; install it with `python -m pip install huggingface_hub`")
    for kind in chosen:
        model = MODELS[kind]
        destination = (args.root / model["dest"]).resolve()
        print(f"\nModel: {model['repo']}\nLicense: {model['license']}\n{model['note']}\nDestination: {destination}")
        confirm = input("Type DOWNLOAD to continue for this model: ").strip()
        if confirm != "DOWNLOAD":
            print("Skipped.")
            continue
        destination.mkdir(parents=True, exist_ok=True)
        snapshot_download(repo_id=model["repo"], local_dir=str(destination))
        print(f"Downloaded {kind} model to {destination}")
    print("Downloads complete. Inference is configured to load local files only.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
