#!/usr/bin/env python3
"""Report local readiness without downloading models or contacting services."""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nia_engine.config import Settings  # noqa: E402
from nia_engine.models import choose_device, EngineError  # noqa: E402


def main() -> int:
    settings = Settings()
    print("NIA Local Engine readiness report (read-only; no network calls)")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Torch installed: {bool(importlib.util.find_spec('torch'))}")
    print(f"Diffusers installed: {bool(importlib.util.find_spec('diffusers'))}")
    print(f"Transformers installed: {bool(importlib.util.find_spec('transformers'))}")
    print(f"Accelerate installed: {bool(importlib.util.find_spec('accelerate'))}")
    print(f"ffmpeg: {shutil.which('ffmpeg') or 'missing'}")
    print(f"ffprobe: {shutil.which('ffprobe') or 'missing'}")
    try:
        print(f"Local compute device: {choose_device(settings.device)}")
    except EngineError as exc:
        print(f"Local compute device: unavailable ({exc})")
    print(f"Image model directory: {settings.image_model_dir}")
    print(f"Image model manifest: {(settings.image_model_dir / 'model_index.json').is_file()}")
    print(f"Video model directory: {settings.video_model_dir}")
    print(f"Video model manifest: {(settings.video_model_dir / 'model_index.json').is_file()}")
    print("Inference network fallback: disabled by implementation")
    print("Note: this report does not prove real generation; run image/video end-to-end tests with installed local weights.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
