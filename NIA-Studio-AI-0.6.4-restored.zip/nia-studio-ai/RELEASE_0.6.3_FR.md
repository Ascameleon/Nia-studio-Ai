# NIA Studio AI 0.6.3 — Double intégration ComfyUI + FLUX.1 schnell

## Livré
- Adaptateur ComfyUI local conservé et relié au fournisseur image.
- Workflow API FLUX.1 schnell ajouté au dépôt et utilisé par défaut si aucun chemin personnalisé n'est défini.
- Remplacement typé des dimensions et de la seed afin de fournir des entiers au graphe ComfyUI.
- Configuration `.env.example` orientée vers le fournisseur ComfyUI pour les images, sans activer d'API distante payante.
- Guide d'installation des poids, de configuration et de validation ajouté.

## Non inclus / non prouvé
- Les poids FLUX et encodeurs ne sont pas inclus dans l'archive.
- ComfyUI n'est pas embarqué ni lancé automatiquement.
- Aucun test de génération réelle n'a été exécuté sans serveur et poids.
- Le résultat doit être validé sur le matériel cible avant de qualifier le moteur d'opérationnel.
