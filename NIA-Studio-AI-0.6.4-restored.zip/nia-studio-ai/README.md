# NIA Studio AI 0.6.4

NIA Studio AI est un studio local-first pour préparer des images, Shorts et vidéos plus longues. Il conserve l’interface, les projets SQLite, le storyboard et les adaptateurs locaux. **Cette version est strictement local-only : aucun fournisseur distant payant ne peut être activé par configuration.**

## Capacités présentes
- Studio web mobile-first, projets et historique SQLite.
- Brief vers storyboard : scènes, durée, narration, direction visuelle et règles de continuité.
- Export de storyboard en Markdown.
- Génération d’image via une instance ComfyUI locale ou le service local NIA.
- Génération vidéo via le service local NIA uniquement.
- Contrôles d’authentification de l’instance, limite de tentatives de connexion et protection des routes privées.
- Endpoints de santé distincts pour le studio, le moteur NIA local et ComfyUI.
- Diagnostic en lecture seule : `python scripts/nia_doctor.py` (aucun téléchargement; ne prouve pas l’inférence).
- Tests de validation, persistance, sécurité et politique de dispatch local-only.

## Limites vérifiées
- Les poids FLUX et les encodeurs ne sont pas inclus.
- ComfyUI n’est pas embarqué ni lancé automatiquement.
- Le moteur NIA local est un service séparé; il n’est pas inclus dans l’application Studio.
- Aucun test de génération réelle image ou vidéo n’a été exécuté dans cette archive.
- Audio/narration, montage multi-plans, cohérence persistante du personnage, timeline et export vidéo final ne sont pas validés de bout en bout.
- Un statut `configured` ou un workflow présent ne signifie pas que le serveur, les poids et l’inférence sont opérationnels. Utiliser `/api/engine/health` et `/api/engine/comfyui/health`, puis exiger un rendu réel inspecté.

## Politique fournisseurs — hard local-only
- Image : `NIA_IMAGE_PROVIDER=local` ou `comfyui`.
- Vidéo : `NIA_VIDEO_PROVIDER=local` uniquement.
- `replicate` retourne HTTP 403 `remote_provider_blocked`, même si d’anciennes variables Replicate ou `NIA_ALLOW_REMOTE_PROVIDERS=true` subsistent dans l’environnement.
- La route `/api/jobs/replicate/{job_id}` est également bloquée.
- Aucun token Replicate n’est requis, lu ou envoyé. Aucune API de génération distante n’est appelée par les routes Studio.

## Structure
```
app/        FastAPI backend, studio routes, local/ComfyUI dispatch, SQLite
static/     interface web, service worker, manifest et icône
tests/      tests API, storyboard, persistance, politique et sécurité
ia_core/    contrats, politique fail-closed, registre et états de tâches
workflows/  workflow API FLUX.1 schnell pour ComfyUI local
```

## Lancer localement
Python 3.11+ recommandé.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows : .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Ouvrir `http://127.0.0.1:8000`. Pour Docker, utiliser `docker build -t nia-studio .` puis `docker run --env-file .env -p 127.0.0.1:8000:8000 -v nia-data:/srv/nia/data nia-studio`. Ne pas exposer le port sans authentification et HTTPS.

## Configuration locale
- `NIA_IMAGE_PROVIDER`: `comfyui` ou `local`.
- `NIA_VIDEO_PROVIDER`: `local`.
- `NIA_COMFYUI_URL`: URL loopback de ComfyUI, par défaut `http://127.0.0.1:8188`.
- `NIA_COMFYUI_WORKFLOW`: chemin facultatif vers un export API ComfyUI; sinon le workflow inclus est utilisé.
- `NIA_COMFYUI_IMAGE_WAIT_SECONDS`: délai de suivi de la génération locale.
- `NIA_LOCAL_ENGINE_URL`: service NIA local, par défaut `http://127.0.0.1:8787`.
- `NIA_LOCAL_IMAGE_WAIT_SECONDS`: délai de suivi image.
- `NIA_DATABASE`: chemin SQLite facultatif.

Les modèles et leurs poids doivent être installés séparément après vérification de la licence exacte. Aucun poids n’est téléchargé automatiquement. Le workflow FLUX.1 schnell et ComfyUI sont locaux; la licence du code ComfyUI et celle des poids sont distinctes.

## API principale
- `GET /api/health`: état du studio et politique d’intégration, sans secrets.
- `GET /api/engine/health`: joignabilité réelle du moteur NIA local.
- `GET /api/engine/comfyui/health`: joignabilité réelle de ComfyUI.
- `POST /api/storyboard`: créer un storyboard.
- `GET/POST /api/projects`: lire et enregistrer les projets.
- `POST /api/generate/image`: génération via moteur local sélectionné.
- `POST /api/generate/video`: génération vidéo via moteur NIA local.
- `GET /api/jobs/local/{job_id}`: suivi d’une tâche locale.

## Tests
```bash
pip install -r requirements-dev.txt
pytest -q tests nia_core/tests
python scripts/nia_doctor.py
```

## Sécurité d’une instance déployée
Pour toute instance accessible depuis Internet, définir `NIA_STUDIO_PASSWORD` et un `NIA_SESSION_SECRET` aléatoire long; définir `NIA_COOKIE_HTTPS_ONLY=true` derrière HTTPS. Sans `NIA_SESSION_SECRET`, l’application refuse de démarrer lorsque le mot de passe est activé. Le service doit rester sur loopback tant que l’authentification, HTTPS et la configuration du proxy ne sont pas vérifiés.

## Portée honnête
NIA Studio AI est notre application et notre pipeline créatif; ce n’est pas un nouveau modèle de fondation entraîné par le projet. La version 0.6.4 sécurise la politique locale, mais **ne certifie pas une génération réelle**. La livraison autonome exige les poids sous licence, un rendu image réel décodé et inspecté, une vidéo réelle lue et vérifiée, les mêmes essais hors réseau, des mesures de performance sur le matériel cible et les tests de sécurité.
