# NIA Studio AI — public development roadmap

## Stage A — assemble the local kernels
- [x] Define an upstream manifest for PyTorch, Diffusers, Transformers, Accelerate, ComfyUI and FFmpeg.
- [x] Add a safe, explicit source checkout script with dry-run mode and no automatic model downloads.
- [x] Add automated tests for the manifest and script import.
- [ ] Fetch and record exact upstream revisions in a network-enabled environment.
- [ ] Select compatible Python/PyTorch/model versions for the target hardware.
- [ ] Add a lockfile or reproducible environment definition after compatibility testing.

## Stage B — strengthen the NIA application body
- [ ] Integrate engine status and model inventory into the UI.
- [ ] Add reliable progress, cancellation, retry and output preview for image/video jobs.
- [ ] Add project assets, prompt history and export organization.
- [ ] Add local-only privacy defaults and explicit opt-in for any community contribution.
- [ ] Test on a supported CPU setup and at least one supported GPU setup when available.

## Stage C — end-to-end acceptance
- [ ] Image generation with local weights; verify PNG signature and decode the image.
- [ ] Video generation with local weights; verify MP4 streams with ffprobe and playback.
- [ ] Confirm no outbound API calls are made in local mode.
- [ ] Audit security, licenses, dependency versions, model provenance and documentation.
- [ ] Publish a tagged release only after these checks pass.

## Public repository policy
- The NIA application code is MIT-licensed.
- Third-party source, dependencies, model weights and generated assets retain their own license and attribution requirements.
- Never commit secrets, private projects, generated user media, large model weights, or local databases.
- Community training data must be opt-in, clearly licensed, and reviewed for privacy and consent.
