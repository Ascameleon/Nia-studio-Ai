# Intégration ComfyUI — NIA Studio AI

NIA propose un adaptateur natif vers une instance **ComfyUI locale**. Il n'installe pas ComfyUI et ne télécharge pas les poids en arrière-plan : l'opérateur conserve le contrôle du moteur, du modèle, du workflow et des licences.

## Configuration

1. Installer ComfyUI depuis le dépôt officiel : https://github.com/Comfy-Org/ComfyUI
2. Installer localement un checkpoint compatible avec le workflow choisi et vérifier la licence du code ET des poids.
3. Dans ComfyUI, construire/tester un workflow d'image puis exporter le **workflow API JSON** (pas le JSON de sauvegarde visuelle).
4. Dans le workflow API, placer `{{prompt}}` dans le champ texte du nœud encodeur de prompt positif. Les placeholders `{{width}}`, `{{height}}` et `{{seed}}` sont facultatifs; ils sont remplacés s'ils existent dans le JSON.
5. Copier le workflow sur la machine NIA et configurer `.env` :

```dotenv
NIA_IMAGE_PROVIDER=comfyui
NIA_COMFYUI_URL=http://127.0.0.1:8188
NIA_COMFYUI_WORKFLOW=/chemin/absolu/workflow-api.json
NIA_COMFYUI_IMAGE_WAIT_SECONDS=900
```

6. Redémarrer NIA et vérifier `/api/health`, puis lancer une génération depuis le studio.

## Limites connues

- Ce dépôt fournit l'adaptateur, pas ComfyUI, les modèles ou un workflow universel : les nœuds dépendent du modèle installé.
- Les URL `/view` retournées pointent vers l'instance ComfyUI. Si le navigateur de l'utilisateur n'est pas sur la même machine/réseau, il faudra ajouter un proxy sécurisé dans NIA; ne pas exposer le port ComfyUI directement sur Internet.
- L'adaptateur doit encore être validé en end-to-end sur une machine disposant de ComfyUI et des poids. Les tests automatisés ne prouvent pas une génération réelle.
- Ne pas activer un workflow qui utilise des nœuds distants payants; le projet vise un pipeline local.
