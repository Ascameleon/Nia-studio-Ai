# Politique local-only NIA 0.6.4

Les routes de génération Studio acceptent uniquement ComfyUI local ou le moteur NIA local pour l’image, et le moteur NIA local pour la vidéo. Les routes Replicate et le suivi de tâches Replicate sont refusés avec HTTP 403. La variable historique `NIA_ALLOW_REMOTE_PROVIDERS` est ignorée; aucun opt-in distant n’est disponible dans cette version.

Les appels HTTP encore présents dans `app/comfyui_engine.py` et `app/local_engine.py` sont dirigés vers les URL locales configurées. Les poids ne sont pas téléchargés au démarrage. Le statut de workflow ne prouve ni la présence des poids, ni la joignabilité du serveur, ni une inférence réelle. Utiliser les endpoints de santé séparés et exécuter un vrai rendu local avant toute qualification opérationnelle.
