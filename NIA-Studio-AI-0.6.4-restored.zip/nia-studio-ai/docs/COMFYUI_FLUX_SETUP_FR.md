# Double intégration ComfyUI + FLUX.1 schnell

NIA contient maintenant un workflow API ComfyUI prêt à configurer : `workflows/flux1_schnell_api.json`. Le code et le workflow sont inclus; les poids du modèle ne le sont pas.

## 1. Installer ComfyUI

Dépôt officiel : https://github.com/Comfy-Org/ComfyUI
Démarrer le serveur localement, par défaut sur `http://127.0.0.1:8188`. Ne pas exposer ce port directement à Internet.

## 2. Installer les fichiers du modèle FLUX.1 schnell

Télécharger les fichiers compatibles depuis la fiche officielle du modèle : https://huggingface.co/black-forest-labs/FLUX.1-schnell et consulter la licence avant usage. Les noms attendus par le workflow sont :

- `ComfyUI/models/diffusion_models/flux1-schnell.safetensors`
- `ComfyUI/models/text_encoders/clip_l.safetensors`
- `ComfyUI/models/text_encoders/t5xxl_fp8_e4m3fn.safetensors`
- `ComfyUI/models/vae/ae.safetensors`

Les noms exacts peuvent varier selon le paquet ou la méthode d'installation; les chemins doivent correspondre aux choix dans le workflow. Redémarrer ComfyUI après ajout des poids.

## 3. Configurer NIA

Dans `.env`, définir uniquement les paramètres locaux suivants. Aucun paramètre d’activation d’un fournisseur distant n’existe dans cette version :

```dotenv
NIA_IMAGE_PROVIDER=comfyui
NIA_COMFYUI_URL=http://127.0.0.1:8188
NIA_COMFYUI_WORKFLOW=
NIA_COMFYUI_IMAGE_WAIT_SECONDS=900
```

Si `NIA_COMFYUI_WORKFLOW` est vide, NIA utilise le workflow FLUX inclus. Pour un workflow personnalisé, renseigner son chemin absolu vers un export **API format** de ComfyUI.

## 4. Validation obligatoire

1. Vérifier que ComfyUI répond à `/system_stats`.
2. Vérifier que les quatre fichiers de modèle sont présents et reconnus.
3. Lancer une image depuis NIA; confirmer que l'historique ComfyUI contient un résultat et que le PNG s'ouvre.
4. Refaire un essai avec le réseau externe désactivé.

## Limites honnêtes

Le workflow est assemblé pour les nœuds standards de ComfyUI et les noms de fichiers ci-dessus, mais n'a pas pu être testé avec une instance ComfyUI réelle et les poids chargés dans cet environnement. Le modèle et ses fichiers auxiliaires ne sont pas intégrés dans l'archive, car ils sont volumineux. Aucune génération réelle n'est revendiquée avant le test de bout en bout sur une machine équipée.
