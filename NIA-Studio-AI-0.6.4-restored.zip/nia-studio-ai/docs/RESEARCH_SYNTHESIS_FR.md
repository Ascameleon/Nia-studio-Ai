# NIA Studio AI — Synthèse technique des audits, critiques et recherches

Date : 26 octobre 2026. Cette note assemble les constats des audits NIA 0.4.0, 0.5.0/0.5.1, du noyau local 0.1.2 et des recherches sur les moteurs. Elle distingue le code présent des composants candidats.

## Décisions d'architecture retenues

1. **Conserver et faire évoluer l'application existante.** L'interface, FastAPI, la persistance des projets, le storyboard et l'adaptateur du moteur local sont conservés. Pas de réécriture à blanc.
2. **Local-only et échec fermé.** NIA 0.6.4 accepte uniquement `local` et `comfyui` pour l’image, et `local` pour la vidéo. Les routes Replicate et leurs appels HTTP ont été retirés du dispatch applicatif; `NIA_ALLOW_REMOTE_PROVIDERS` n’est plus reconnu. Aucun basculement distant.
3. **Séparer le studio du moteur d'inférence.** Le studio gère brief, storyboard, projets et tâches; le service local gère files, exécution, validation et fichiers de sortie. La disponibilité HTTP du service ne signifie pas que les poids sont installés.
4. **Provenance et preuve.** Chaque modèle doit avoir une révision précise, une licence vérifiée pour les poids exacts, un chemin local et un statut d'inférence. Les candidats restent `not_tested` tant qu'un vrai rendu n'a pas passé les tests d'acceptation.
5. **Valider les fichiers, pas seulement les réponses API.** Un PNG doit être décodable et un MP4 doit contenir un flux vidéo lisible et une durée positive. Les tests de fixtures prouvent la validation, pas la capacité d'un modèle à générer.
6. **Concevoir la cohérence autour des modèles.** La différenciation produit est la chaîne brief → storyboard → références/identité du personnage → plans → sélection/régénération → assemblage → audio/sous-titres/export. Aucun modèle seul ne garantit une vidéo multi-plans cohérente.

## Résultats d'audit repris

- NIA 0.4.0 dépendait de Replicate pour générer; ses 13 tests ne démontraient pas une génération autonome.
- L'intégration 0.5.0 a introduit le service local et passé 14 tests, mais aucun poids n'était installé et aucune inférence réelle n'a été validée.
- Le noyau 0.1.2 a renforcé les contrôles PNG/MP4, la limite de file et la récupération de tâches; ses 16 tests utilisaient des fixtures et des doubles de test.
- La version 0.6.0 passe 27 tests dans l'environnement de construction. Cela valide les contrats logiciels présents, pas une génération réelle.

## Moteurs étudiés — statut de candidat, pas d'intégration revendiquée

| Usage | Candidat étudié | Intérêt | Risque / travail restant |
|---|---|---|---|
| Image | FLUX.1 schnell | Génération rapide; licence souvent indiquée Apache-2.0 pour cette variante | Confirmer la licence de la fiche exacte, révision, poids et compatibilité du pipeline |
| Vidéo | Wan 2.2 TI2V-5B | Candidat texte/image vers vidéo | Coût matériel/temps, poids volumineux, adaptation de pipeline et validation MP4 |
| Vidéo | LTX-Video | Candidat axé sur la vitesse | Choisir une version précise; vérifier licence des poids et intégration audio/vidéo de cette version |
| Orchestration locale | ComfyUI | API/workflows modulaires, file et vaste écosystème | Déploiement séparé, conformité GPL-3.0 si redistribué, sécurité API et audit des nœuds distants |
| Montage/pipeline | OpenVideoStudio / InvokeAI | Inspirations de workflow, reprise et édition | Projets tiers non intégrés; audit du code, des licences et des dépendances avant réutilisation |

Les licences du code et celles des poids sont distinctes. Ne pas considérer un dépôt public comme une autorisation globale d'utiliser ou redistribuer tous ses modèles.

## Blocages encore ouverts avant une livraison autonome

- Les poids de modèles ne sont pas livrés avec le ZIP et aucune génération réelle n'a été exécutée.
- L'adaptateur de modèle générique Diffusers ne suffit pas à garantir la compatibilité avec chaque architecture. Il faut un adaptateur explicitement testé pour la révision retenue.
- Le pipeline complet multi-plans, cohérence de personnage, narration, musique, sous-titres, montage et export final n'est pas encore démontré bout en bout.
- Le matériel cible n'est pas connu/benchmarké; aucune promesse de vitesse ou de résolution ne doit être faite avant mesure.
- Les tests hors ligne, les empreintes de poids, les licences exactes, la sécurité de l'API locale et la récupération sous charge restent des critères de sortie.

## Définition de « prêt »

La livraison autonome n'est validée qu'après : (a) modèle/révision/licence/empreinte consignés; (b) vrai prompt d'image généré et PNG décodé/inspecté; (c) vraie vidéo générée, flux/durée/dimensions vérifiés et lecture contrôlée; (d) mêmes essais réussis sans réseau après installation des poids; (e) tests de panne/file/sécurité; (f) rapport de performance sur le matériel cible.
