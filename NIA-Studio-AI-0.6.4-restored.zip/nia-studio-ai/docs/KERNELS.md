# NIA Studio AI — upstream kernel assembly

The intended upstream components are deliberately modular. Keep each upstream license and model license with the installation; the code license does not automatically cover model weights.

| Component | Upstream repository | Responsibility | Integration policy |
|---|---|---|---|
| PyTorch | https://github.com/pytorch/pytorch | Tensor compute and inference runtime | Install a build matching the target CPU/GPU; do not blindly install CUDA builds |
| Diffusers | https://github.com/huggingface/diffusers | Diffusion pipelines | Optional model runtime dependency; local-only model loading |
| Transformers | https://github.com/huggingface/transformers | Text and multimodal model pipelines | Optional model runtime dependency |
| Accelerate | https://github.com/huggingface/accelerate | Model/device placement | Install with the selected model stack |
| ComfyUI | https://github.com/Comfy-Org/ComfyUI | Workflow server for image/video generation | Separate process/environment; accessed through local API |
| FFmpeg | https://github.com/FFmpeg/FFmpeg | Media conversion, muxing and validation | System executable, not a generative model |

## Safety and reproducibility

- Do not download model weights automatically during normal startup.
- Keep model weights outside Git and record model name, revision, hash, source and license.
- Keep generation on localhost by default; never expose ComfyUI or NIA engine ports publicly without authentication.
- Local engine requests must fail clearly if the engine/model is unavailable. No silent cloud fallback.
- The bootstrap helper clones upstream source repositories only when explicitly invoked and the machine has network access. It does not install GPU drivers or download large model weights.

## Current execution environment limitation

At integration time, outbound DNS/network access to GitHub was unavailable. Therefore the upstream repositories could not be cloned into this workspace in this run. This integration packages the existing NIA local-engine source and defines reproducible upstream references; the clone/bootstrap step still needs to run in an environment with GitHub access.
