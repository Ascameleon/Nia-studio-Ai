# Rapport de livraison — NIA Studio AI 0.6.1

## Changements dans cette consolidation
- Conservation du code applicatif et du moteur local de la version 0.6.0.
- Ajout d'une synthèse unique des audits et recherches moteurs, avec séparation explicite entre composants présents et candidats.
- Ajout de `scripts/nia_doctor.py`, diagnostic en lecture seule qui vérifie les dépendances, FFmpeg/ffprobe, le périphérique PyTorch et la présence de `model_index.json` sans télécharger quoi que ce soit.
- Ajout d'un test automatisé vérifiant que le diagnostic n'invente pas des poids et ne crée pas de dossiers modèles.
- Version de paquet Python mise à jour en 0.6.1.

## Vérification exécutée dans l'environnement de construction
- Suite principale studio/noyau commun : **28 tests réussis** (`pytest -q`).
- Suite du moteur local autonome : **16 tests réussis** (`PYTHONPATH=. pytest -q` depuis `nia-autonomous-engine/`).
- Total observé : **44 tests réussis** sur les deux suites; les tests ne constituent pas une preuve de génération réelle.
- Le diagnostic de pré-vol ne remplace pas l'inférence réelle.
- Aucun modèle/poids n'a été téléchargé; aucune API payante n'a été appelée.

## Limite bloquante
Le projet n'est pas encore qualifié comme générateur local autonome opérationnel. Les adaptateurs doivent être validés contre des révisions précises de modèles compatibles; la génération réelle PNG/MP4, la lecture vidéo, le fonctionnement hors ligne et les performances sur matériel cible restent des tests de sortie obligatoires.
